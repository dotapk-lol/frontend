// Generated from legacy-three.js; stable across bundling.
export const behaviorCodeHash='a3f7e82f8eb718630a1c166666c126550577e30bcd9dc237022832932ff627cf';
