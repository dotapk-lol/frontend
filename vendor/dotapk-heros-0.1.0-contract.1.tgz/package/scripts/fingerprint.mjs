import fs from 'node:fs';import {createHash} from 'node:crypto';
const source=fs.readFileSync(new URL('../rules/legacy-three.js',import.meta.url));
const digest=createHash('sha256').update(source).digest('hex');
fs.writeFileSync(new URL('../rules/fingerprint.js',import.meta.url),`// Generated from legacy-three.js; stable across bundling.\nexport const behaviorCodeHash='${digest}';\n`);
