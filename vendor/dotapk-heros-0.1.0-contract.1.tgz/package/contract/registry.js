import {heroes} from '../content/index.js';
import {legacyThreeFactories} from '../rules/legacy-three.js';
import {canonical,freeze,json,sha256} from './value.js';
export const BATTLE_ABI='heros-effects-1';
export const CAPABILITIES=Object.freeze(['damage','heal','mana','transfer-mana','self-damage','protect','status','control','target-route','motion-request','projectile-request','legacy-effect','schedule','action-token','deferred-hp','cue']);
export const HOOKS=Object.freeze(['planCast','onCastCommitted','activate','onContact','onInterrupt','onDeath','projectAttack','projectDamage','projectHealing','projectInterval','onAttack','onDamage','onTargeted','onStage']);
const semver=v=>typeof v==='string'&&/^\d+\.\d+\.\d+$/.test(v);
function validateDefinition(hero){
 const h=json(hero);
 if(!Number.isSafeInteger(h.registryNumericId)||!Number.isSafeInteger(h.valveHeroId)||typeof h.id!=='string'||!Array.isArray(h.abilities)||h.abilities.length!==4)throw Error('Invalid hero identity/schema');
 for(const k of ['hp','mana_regen','attack','move_speed','attack_range','attack_interval_s'])if(!Number.isFinite(h[k])||h[k]<0)throw Error('Invalid hero coefficient: '+k);
 for(const k of ['mana','combatHp','combatMana'])if(h[k]!==undefined&&(!Number.isFinite(h[k])||h[k]<0))throw Error('Invalid optional hero coefficient: '+k);
 const ids=new Set();for(const a of h.abilities){if(typeof a.id!=='string'||ids.has(a.id)||!a.mvp||typeof a.mvp.passive!=='boolean')throw Error('Invalid ability identity/schema');ids.add(a.id);for(const k of ['mana','cooldown_s','range_wu','startup_frames','recovery_frames'])if(!Number.isFinite(a.mvp[k])||a.mvp[k]<0)throw Error('Invalid skill coefficient: '+k);}
 return freeze(h);
}
function validateImplementation(impl){
 if(!impl||typeof impl.behaviorId!=='string'||!impl.behaviorId||!semver(impl.revision)||!Array.isArray(impl.requires)||new Set(impl.requires).size!==impl.requires.length||impl.requires.some(c=>!CAPABILITIES.includes(c))||typeof impl.validateState!=='function')throw Error('Invalid behavior metadata/capabilities');
 if(impl.namespace!==undefined&&(typeof impl.namespace!=='string'||!/^heros\/[a-z0-9/_-]{1,96}$/.test(impl.namespace)))throw Error('Invalid owned rule namespace');
 if(impl.stateVersion!==undefined&&!semver(impl.stateVersion))throw Error('Invalid namespace schema version');
 if(impl.codeHash!==undefined&&(typeof impl.codeHash!=='string'||!/^[0-9a-f]{64}$/.test(impl.codeHash)))throw Error('Invalid declared implementation digest');
 const allowed=new Set(['behaviorId','revision','requires','validateState','scheduledHandlers','namespace','stateVersion','codeHash',...HOOKS]);
 for(const k of Object.keys(impl)){if(!allowed.has(k))throw Error('Unknown behavior field: '+k);if(HOOKS.includes(k)&&typeof impl[k]!=='function')throw Error('Invalid behavior hook');}
 if(!HOOKS.some(k=>typeof impl[k]==='function'))throw Error('Empty implementation');
 if(impl.scheduledHandlers!==undefined){if(!impl.scheduledHandlers||Object.getPrototypeOf(impl.scheduledHandlers)!==Object.prototype||Object.entries(impl.scheduledHandlers).some(([k,v])=>!/^[-\w]{1,64}$/.test(k)||typeof v!=='function'))throw Error('Invalid scheduled handlers');}
 return Object.freeze({...impl,requires:Object.freeze([...impl.requires]),scheduledHandlers:Object.freeze({...impl.scheduledHandlers})});
}
const key=(heroId,slot)=>heroId+':'+slot;
const stateSchemaDigest=impl=>sha256(Function.prototype.toString.call(impl.validateState));
function behaviorManifest(impl){return {behaviorId:impl.behaviorId,revision:impl.revision,requires:impl.requires,namespace:impl.namespace??null,stateVersion:impl.stateVersion??'1.0.0',codeHash:impl.codeHash??null,hooks:[...HOOKS,'validateState'].filter(k=>impl[k]),scheduledHandlers:Object.keys(impl.scheduledHandlers).sort()};}
export function createHeroRegistry(initial=heroes,{defaults=true}={}){
 // The candidate's scope is the frozen 46 identities. This is an extension API
 // for their behavior/configuration, not an admission API for new roster IDs.
 if(!Array.isArray(initial)||initial.length!==heroes.length)throw Error('Expected frozen 46 roster');
 const identity=new Map(heroes.map(h=>[h.registryNumericId,h])),rows=new Map();let locked=false,cached;
 function checkIdentity(h){const expected=identity.get(h.registryNumericId);if(!expected||expected.id!==h.id||expected.valveHeroId!==h.valveHeroId||h.abilities.some((a,i)=>a.id!==expected.abilities[i].id))throw Error('Out-of-scope hero/ability identity');}
 for(const source of initial){const h=validateDefinition(source);checkIdentity(h);if(rows.has(h.registryNumericId))throw Error('Duplicate hero');rows.set(h.registryNumericId,h);}
 const factories=new Map();let definitionCache;
 function allDefinitions(){return definitionCache??=freeze([...rows.values()]);}
 function factoryAt(heroId,slot,factory,definition){
  if(!rows.has(heroId)||!Number.isInteger(slot)||slot<0||slot>3||!factory||factory.abiVersion!==BATTLE_ABI||typeof factory.create!=='function')throw Error('Invalid factory/ABI/slot');
  const hero=definition?freeze({...rows.get(heroId),abilities:rows.get(heroId).abilities.map((a,i)=>i===slot?definition:a)}):rows.get(heroId);
  const definitions=definition?freeze(allDefinitions().map(h=>h.registryNumericId===heroId?hero:h)):allDefinitions();
  return validateImplementation(factory.create(Object.freeze({hero,definition:hero.abilities[slot],definitions})));
 }
 function registerFactory(heroId,slot,factory){
  if(locked)throw Error('Registry sealed');const id=key(heroId,slot);if(factories.has(id))throw Error('Duplicate skill implementation');checkSharedSchema(id,factoryAt(heroId,slot,factory));factories.set(id,Object.freeze({...factory}));return api;
 }
 function checkSharedSchema(id,impl){if(!impl.namespace)return;const stamp=behaviorManifest(impl);for(const [otherId,otherFactory] of factories){if(otherId===id)continue;const [heroId,slot]=otherId.split(':').map(Number),other=factoryAt(heroId,slot,otherFactory);if(other.namespace!==impl.namespace)continue;const metadata=behaviorManifest(other);if(stamp.stateVersion!==metadata.stateVersion||stateSchemaDigest(impl)!==stateSchemaDigest(other))throw Error('Inconsistent shared namespace schema');}}
 function replaceSkill(heroId,slot,replacement,expected){
  if(locked)throw Error('Registry sealed');const hero=rows.get(heroId),oldFactory=factories.get(key(heroId,slot));if(!hero||!oldFactory)throw Error('No registered skill');
  const old=hero.abilities[slot],oldImpl=factoryAt(heroId,slot,oldFactory);
  if(!expected||expected.abilityId!==old.id||expected.revision!==oldImpl.revision)throw Error('Stale expected ability/revision');
  if(!replacement?.definition||replacement.definition.id!==old.id)throw Error('Replacement must retain selected ability identity');
  const next=validateDefinition({...hero,abilities:hero.abilities.map((a,i)=>i===slot?replacement.definition:a)});
  const nextFactory=replacement.factory??oldFactory,nextImpl=factoryAt(heroId,slot,nextFactory,next.abilities[slot]);if(replacement.factory&&nextImpl.behaviorId===oldImpl.behaviorId&&nextImpl.revision===oldImpl.revision&&nextImpl.codeHash===oldImpl.codeHash)throw Error('Behavior replacement requires a changed revision or implementation digest');checkSharedSchema(key(heroId,slot),nextImpl);
  // All schema, ABI, factory and optimistic revision checks finish before commit.
  rows.set(heroId,next);definitionCache=undefined;factories.set(key(heroId,slot),Object.freeze({...nextFactory}));return api;
 }
 function seal(){
  if(cached)return cached;
  const definitions=allDefinitions(),implementations=new Map(),manifest=[],schemas=new Map();
  for(const [id,factory] of factories){const [heroId,slot]=id.split(':').map(Number),impl=factoryAt(heroId,slot,factory),record=behaviorManifest(impl);if(impl.namespace){const schema=record.stateVersion+':'+stateSchemaDigest(impl);if(schemas.has(impl.namespace)&&schemas.get(impl.namespace)!==schema)throw Error('Inconsistent shared namespace schema');schemas.set(impl.namespace,schema);}implementations.set(id,impl);manifest.push({heroId,slot,abilityId:rows.get(heroId).abilities[slot].id,...record});}
  const rosterHash=sha256(canonical(definitions.map(h=>({heroId:h.registryNumericId,valveHeroId:h.valveHeroId,id:h.id,abilities:h.abilities.map(a=>a.id)})))),rulesHash=sha256(canonical({abi:BATTLE_ABI,definitions,manifest:manifest.sort((a,b)=>a.heroId-b.heroId||a.slot-b.slot)}));
  cached=Object.freeze({abiVersion:BATTLE_ABI,rulesHash,rosterHash,definitions,manifest:freeze(manifest),hero:heroId=>rows.get(heroId)??null,implementation:(heroId,slot)=>implementations.get(key(heroId,slot))??null});locked=true;return cached;
 }
 const api=Object.freeze({registerFactory,replaceSkill,seal,definition:heroId=>rows.get(heroId)??null});
 if(defaults)for(const row of legacyThreeFactories)registerFactory(row.heroId,row.slot,{abiVersion:BATTLE_ABI,create:row.create});
 return api;
}
