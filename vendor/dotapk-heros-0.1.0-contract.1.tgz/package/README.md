# @dotapk/heros — effects contract vertical slice

Private review candidate, not a complete 46-hero executable release. Includes the
frozen 46 hero / 184 ability numeric definitions, but **only three** migrated
implementations: Anti-Mage Blink, Anti-Mage Mana Void, Lion Hex. Other abilities
still execute privately while their authors migrate them through this contract.

The package has no Engine, main loop, AI, inputs, physics, rounds, network, media,
accounts, or full-world checkpoint. An implementation receives detached frozen
actor facts and only its declared named ports. The host owns RNG/time and commits
HP, MP, controls and movement once. Rules snapshots contain namespace state only.
This is a trusted static plugin contract, not a JavaScript security sandbox.

`createHeroRegistry()` initializes the frozen 46 identities plus three defaults.
`registerFactory(heroId, slot, {abiVersion: BATTLE_ABI, create})` registers each
remaining selected skill. The factory captures coefficients from its own sealed
registry, avoiding process-global Maps of old definitions. `replaceSkill` requires
the existing ability ID and implementation revision; failed validation changes
nothing. Sealing freezes definition and behavior manifests and SHA-256 hashes.
Rules identities include a declared source digest, behavior ID/revision, hook
names, capabilities and numeric definitions. The default three handlers' digest
is generated from their source before packaging. Formatting changes introduced by
bundling do not change the rules identity. Static author plugins must declare
their own codeHash and update it/revision when behavior changes. This declaration
is for trusted static plugins; it does not attest arbitrary untrusted JavaScript.

`createRuleSession(sealed).invoke(heroId,slot,hook,host,event)` returns a handled
flag plus JSON return value. `host` supplies `now()`, `actor(id)`, `random()` and
`ports`; it must not pass an Engine as the actor or accept catch-all mutations.
Namespace state uses `ctx.state.read()/write(value)/remove()` and must satisfy the
implementation's `validateState`. By default this state belongs to one skill.
Related hooks/skills may declare a shared `namespace: 'heros/group/name'` and
`stateVersion`; sealing rejects conflicting schema validators/versions. Their
factory configuration shares one frozen `definitions` identity per sealed registry,
so a group can use a WeakMap keyed by it to compile its coefficient caches once.
See `contract/types.ts` for the owned interface.

Port families are declared now; the private vertical-slice host implements only
damage, control.apply, motion, protect, target.route and cue. Unsupported ports are an explicit
integration blocker, not simulated behavior. The public test host has only resource
transactions and fixed contact facts. It is not a copied game simulation.

Run `npm test` with Node 22+. Public GitHub / npm publication remains blocked until
independent boundary review and all 46 implementations and private regressions pass.
