// Public compile-only compatibility probes; no private host/Engine dependency.
import type {SkillContext,SkillImplementation,StatusSpec,StatusView,StatusRecordView,Json} from '../contract/types.ts';

const legacy:StatusSpec={owner:0,target:1,abilityId:'probe',key:'probe',duration:4,
 polarity:'negative',dispel:'basic',pierces:false,values:{dps:12}};
const periodic:StatusSpec={...legacy,intervalSeconds:.25};
const legacyQuery:SkillContext['status']['query']=(_target,_key)=>[legacy];
const newQuery:SkillContext['status']['query']=(_target,_key)=>[{...periodic,
 handle:'status:1',effective:false,remainingSeconds:3.5}];
const oldConsumer:readonly Readonly<StatusSpec>[]=newQuery(1,'probe');
const newConsumer:readonly Readonly<StatusView>[]=legacyQuery(1,'probe');
const strict:StatusRecordView={...periodic,handle:'status:1',effective:true,remainingSeconds:1};
const compatible:StatusView=strict;
const voidHook:NonNullable<SkillImplementation['onStage']>=(_ctx,_event)=>{};
const resultHook:NonNullable<SkillImplementation['onStage']>=(_ctx,_event)=>({commands:[{kind:'probe'}]});
const stageResult:ReturnType<NonNullable<SkillImplementation['onStage']>>={statusRefresh:{target:1,key:'probe',duration:4}};
const jsonResult:Json={statusBlockUpdate:{target:1,key:'probe',remainingBlock:-1,removeAtZero:true}};
void [oldConsumer,newConsumer,compatible,voidHook,resultHook,stageResult,jsonResult];

// @ts-expect-error Optional metadata does not upgrade a legacy row into a strict record.
const missingRecord:StatusRecordView=legacy;
// @ts-expect-error Strict view must include effective.
const missingEffective:StatusRecordView={...periodic,handle:'status:2',remainingSeconds:1};
// @ts-expect-error Strict view must include remainingSeconds.
const missingRemaining:StatusRecordView={...periodic,handle:'status:2',effective:true};
// @ts-expect-error The interval is numeric.
const stringInterval:StatusSpec={...legacy,intervalSeconds:'0.25'};
// @ts-expect-error Effective is a boolean, not truthy JSON.
const stringEffective:StatusRecordView={...strict,effective:'true'};
// @ts-expect-error Query results cannot be pushed into.
newConsumer.push(legacy);
// @ts-expect-error Query metadata cannot be assigned.
newConsumer[0].handle='replacement';
// @ts-expect-error Status values are readonly.
strict.values.dps=99;
// @ts-expect-error Status cadence is readonly.
periodic.intervalSeconds=1;
// @ts-expect-error A stage hook cannot return a function outside JSON.
const nonJsonHook:NonNullable<SkillImplementation['onStage']>=(_ctx,_event)=>()=>1;
void [missingRecord,missingEffective,missingRemaining,stringInterval,stringEffective,nonJsonHook];
