import test from 'node:test';
import assert from 'node:assert/strict';
import {createHeroRegistry,createRuleSession,BATTLE_ABI,codeIdentity,EMPTY_STATE_SCHEMA} from '../index.js';
import {testHost} from './host.mjs';

// Synthetic public provider: records delivery, never implements a native timer or Engine.
const declaration={id:'probe:periodic',key:'probe',recipient:'enemy',duration:4,interval:.025,
 programId:'probe:tick',schedule:{handler:'pulse',binding:'status',delivery:'actor.status-advance'},
 polarity:'negative',dispel:'basic',pierces:false,values:{dps:12}};
function fixture({rows=[],declared=false}={}){
 const r=createHeroRegistry(undefined,{defaults:false}),base=testHost(),calls=[];
 const factory={abiVersion:BATTLE_ABI,parameters:{declared},create:()=>({
  behaviorId:'public/status-payload/probe',revision:'1.0.0',
  ...codeIdentity(['test/status-payload.test.mjs']),requires:declared?['status','schedule']:['status'],
  stateSchema:EMPTY_STATE_SCHEMA,
  ...(declared?{statusDeclarations:[declaration],
   scheduledBindings:{pulse:[{binding:'status',delivery:'actor.status-advance'}]},
   scheduledHandlers:{pulse:(_ctx,data)=>data}}:{}),
  onStage(ctx,e){
   if(e.kind==='apply')return ctx.status.apply(e.spec);
   if(e.kind==='schedule')return ctx.schedule(e.spec);
   if(e.kind==='query')return ctx.status.query(e.actor,e.key);
   if(e.kind==='facts')return e;
   if(e.kind==='projection')return e.projection;
   throw Error('Unknown probe event');
  }
 })};
 r.registerFactory(5,3,factory);const sealed=r.seal(),session=createRuleSession(sealed);
 const host={...base.host,ports:{...base.host.ports,status:{
  apply(spec){calls.push({method:'apply',spec});return 'status:g1:1';},
  query(target,key){calls.push({method:'query',target,key});return rows;},
  remove(handle){calls.push({method:'remove',handle});return true;},cleanse(){return [];}
 },schedule(spec){calls.push({method:'schedule',spec});return 'job:g1:1';},cancelJob(){return true;}}};
 const invoke=e=>session.invoke(5,3,'onStage',host,e).value;
 const spec={owner:0,target:1,abilityId:sealed.hero(5).abilities[3].id,key:'probe',duration:4,
  polarity:'negative',dispel:'basic',pierces:false,values:{dps:12}};
 return {invoke,spec,calls,session,host};
}

test('legacy status apply still omits interval and delivers the same request shape',()=>{
 const x=fixture();assert.equal(x.invoke({kind:'apply',spec:x.spec}),'status:g1:1');
 assert.deepEqual(x.calls[0].spec,x.spec);assert(!Object.hasOwn(x.calls[0].spec,'intervalSeconds'));
});
test('fractional intervalSeconds reaches the provider unchanged without extra allocation',()=>{
 const x=fixture(),spec={...x.spec,intervalSeconds:.025};
 x.invoke({kind:'apply',spec});assert.equal(x.calls.length,1);
 assert.equal(x.calls[0].spec.intervalSeconds,.025);assert.deepEqual(spec.values,{dps:12});
});
test('spec-only legacy query rows remain valid readonly result transport',()=>{
 const x=fixture(),row={...x.spec,values:{dps:12}},y=fixture({rows:[row]});
 const result=y.invoke({kind:'query',actor:1,key:'probe'});
 assert.deepEqual(result,[row]);assert(Object.isFrozen(result));assert(Object.isFrozen(result[0]));
 assert(!Object.hasOwn(result[0],'handle'));assert(!Object.hasOwn(result[0],'effective'));
});
test('record metadata and nested query values are detached and frozen',()=>{
 const row={...fixture().spec,handle:'status:g1:1',effective:false,enabled:false,
  remainingSeconds:3.75,intervalSeconds:.025,values:{dps:12,nested:{origin:0}}};
 const x=fixture({rows:[row]}),result=x.invoke({kind:'query',actor:1,key:'probe'});
 assert.equal(result[0].effective,false);assert.equal(result[0].remainingSeconds,3.75);
 assert.throws(()=>result.push(row),TypeError);assert.throws(()=>result[0].handle='other',TypeError);
 assert.throws(()=>result[0].values.nested.origin=1,TypeError);
 row.values.nested.origin=1;row.remainingSeconds=0;
 assert.equal(result[0].values.nested.origin,0);assert.equal(result[0].remainingSeconds,3.75);
 assert.deepEqual(x.calls,[{method:'query',target:1,key:'probe'}]);
});
test('periodic facts preserve enabled=false and readonly authenticated-provider fields',()=>{
 const x=fixture(),event={kind:'status-periodic',actor:1,status:{...x.spec,handle:'status:g1:1',
  effective:false,remainingSeconds:2,intervalSeconds:.25},intervalSeconds:.25,enabled:false};
 const result=x.invoke({kind:'facts',payload:event}).payload;
 assert.deepEqual(result,event);assert(Object.isFrozen(result.status.values));
 event.status.remainingSeconds=0;assert.equal(result.status.remainingSeconds,2);
 assert.equal(x.calls.length,0);
});
test('JSON transport is not a closed B validator or a resource authenticator',()=>{
 const x=fixture();const payload={kind:'status-periodic',actor:1,status:{key:'invented'},
  intervalSeconds:-1,enabled:'true'};
 assert.deepEqual(x.invoke({kind:'facts',payload}).payload,payload);
 // Opted-in owned validators/provider must reject these finite but semantically wrong facts.
 assert.equal(x.calls.length,0);
 assert.throws(()=>x.invoke({kind:'facts',payload:{...payload,intervalSeconds:NaN}}),/finite|JSON/i);
});
test('onStage returns detached JSON intents without adding mutation ports',()=>{
 const x=fixture(),projection={statusRefresh:{target:1,key:'probe',duration:4,
  resetElapsed:true,preserveTick:true}};
 const result=x.invoke({kind:'projection',projection});assert.deepEqual(result,projection);
 assert.throws(()=>result.statusRefresh.duration=9,TypeError);
 projection.statusRefresh.duration=9;assert.equal(result.statusRefresh.duration,4);
 assert.equal(x.calls.length,0);
});
test('block projection preserves finite negative removal counter and does not commit it itself',()=>{
 const x=fixture(),projection={damage:10,statusBlockUpdate:{target:1,key:'probe',
  remainingBlock:-5,removeAtZero:true}};
 assert.deepEqual(x.invoke({kind:'projection',projection}),projection);assert.equal(x.calls.length,0);
});
test('declared periodic apply keeps its exact old shape and source cadence binding',()=>{
 const x=fixture({declared:true});const spec={...x.spec,statusDeclarationId:declaration.id};
 x.invoke({kind:'apply',spec});assert.equal(x.calls.length,1);
 const schedule={abilityId:x.spec.abilityId,owner:0,target:1,handler:'pulse',delay:.025,data:{},
  binding:{kind:'status',ref:'status:g1:1'},delivery:'actor.status-advance',statusDeclarationId:declaration.id};
 x.invoke({kind:'schedule',spec:schedule});assert.equal(x.calls[1].spec.delay,.025);
});
test('optional interval type does not weaken exact opt-in status declarations',()=>{
 const x=fixture({declared:true});
 for(const delta of [{intervalSeconds:.025},{intervalSeconds:1},{enabled:true},{effective:true},
  {handle:'status:g1:1'},{remainingSeconds:4}]){
  assert.throws(()=>x.invoke({kind:'apply',spec:{...x.spec,statusDeclarationId:declaration.id,...delta}}),
   /declared status source parameters/);
 }
 assert.equal(x.calls.length,0);
});
test('declared schedule rejects substituted cadence or intervalSeconds before allocation',()=>{
 const x=fixture({declared:true}),spec={abilityId:x.spec.abilityId,owner:0,target:1,handler:'pulse',
  delay:.025,data:{},binding:{kind:'status',ref:'status:g1:1'},delivery:'actor.status-advance',statusDeclarationId:declaration.id};
 assert.throws(()=>x.invoke({kind:'schedule',spec:{...spec,delay:.05}}));
 assert.throws(()=>x.invoke({kind:'schedule',spec:{...spec,intervalSeconds:.025}}));
 assert.equal(x.calls.length,0);
});
test('nested routed actors do not bypass or confuse existing top-level owner identity check',()=>{
 const x=fixture();assert.deepEqual(x.invoke({kind:'facts',facts:{owner:1,target:0}}).facts,{owner:1,target:0});
 assert.throws(()=>x.invoke({kind:'facts',owner:1,facts:{owner:1,target:0}}),/owner hero/);
});
