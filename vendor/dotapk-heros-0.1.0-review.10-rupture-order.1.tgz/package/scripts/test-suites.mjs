export const suites=Object.freeze([
  {
    "name": "contract",
    "minimumPass": 30,
    "files": [
      "test/contract.test.mjs"
    ]
  },
  {
    "name": "schedule",
    "minimumPass": 49,
    "files": [
      "test/schedule-schema.test.mjs"
    ]
  },
  {
    "name": "core4",
    "minimumPass": 42,
    "files": [
      "test/core4/rules.test.mjs"
    ]
  },
  {
    "name": "a",
    "minimumPass": 271,
    "files": [
      "test/a-rules.test.mjs",
      "test/a-six-handlers.test.mjs",
      "test/a-v2-contract.test.mjs",
      "test/a-v3-resources.test.mjs",
      "test/a-v4-schedule.test.mjs"
    ]
  },
  {
    "name": "b",
    "minimumPass": 230,
    "files": [
      "test/b24.test.mjs"
    ]
  },
  {
    "name": "c",
    "minimumPass": 240,
    "files": [
      "test/c/boundaries.test.mjs",
      "test/c/effect-diff.test.mjs",
      "test/c/skills.test.mjs"
    ]
  },
  {
    "name": "legacy0-9",
    "minimumPass": 15,
    "files": [
      "test/legacy-0-9.test.mjs",
      "test/legacy-projections.test.mjs"
    ]
  },
  {
    "name": "legacy-next",
    "minimumPass": 22,
    "files": [
      "test/legacy-next.test.mjs"
    ]
  },
  {
    "name": "legacy10-19",
    "minimumPass": 108,
    "files": [
      "test/legacy-10-19/slices.test.mjs",
      "test/legacy-10-19/proposed.test.mjs",
      "test/legacy-10-19/remaining.test.mjs"
    ]
  },
  {
    "name": "legacy-remaining",
    "minimumPass": 69,
    "files": ["test/legacy-remaining.test.mjs"]
  },
  {
    "name": "batch10-contract",
    "minimumPass": 74,
    "files": ["test/batch10-contract.test.mjs"]
  },
  {
    "name": "unified",
    "minimumPass": 15,
    "files": [
      "test/unified.test.mjs"
    ]
  },
  {
    "name": "cleave-p2",
    "minimumPass": 14,
    "files": ["test/legacy-10-19/cleave-p2.test.mjs"]
  },
  {
    "name": "status-payload",
    "minimumPass": 12,
    "files": ["test/status-payload.test.mjs"]
  }
].map(Object.freeze));
