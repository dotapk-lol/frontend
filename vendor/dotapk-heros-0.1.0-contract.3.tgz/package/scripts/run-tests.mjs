import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {spawnSync} from 'node:child_process';import {createHash} from 'node:crypto';
import {sourceManifest} from '../rules/fingerprint.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
for(const required of ['test/contract.test.mjs','test/host.mjs','test/probes.mjs'])if(!fs.existsSync(path.join(root,required)))throw Error('Missing shipped test fixture: '+required);
for(const [file,digest] of Object.entries(sourceManifest))if(!fs.existsSync(path.join(root,file))||createHash('sha256').update(fs.readFileSync(path.join(root,file))).digest('hex')!==digest)throw Error('Source fingerprint mismatch: '+file);
const result=spawnSync(process.execPath,['--test','--test-reporter=tap','test/contract.test.mjs'],{cwd:root,encoding:'utf8'});process.stdout.write(result.stdout??'');process.stderr.write(result.stderr??'');
const metric=name=>Number(result.stdout?.match(new RegExp('^# '+name+' (\\d+)$','m'))?.[1]??-1);
const count=metric('tests'),passed=metric('pass'),failed=metric('fail'),skipped=metric('skipped'),todo=metric('todo');if(result.status!==0||count<30||passed<30||failed!==0||skipped!==0||todo!==0)throw Error('Contract suite failed or insufficient actual passes: '+JSON.stringify({count,passed,failed,skipped,todo}));
