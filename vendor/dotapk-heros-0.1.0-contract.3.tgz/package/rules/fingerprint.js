// Generated from actual package source files; no Function.toString identity.
export const sourceManifest={
  "content/heroes.json": "b837cb0c5c601092c7ce1b0d2fda6a90bcde8b6d797149cbac9cc9cf3d381b7d",
  "content/index.js": "e552bf8888a58f1c171e430e36a4767157eaf43d717cd7b3195d3a8643cf85e1",
  "contract/code-identity.js": "b211e83f16c3aa84e79b1d5e2fdb36c33a4e55a329e45f357496f8402340d3f8",
  "contract/definition-schema.js": "c03e8f8df8cd88a8b23c86cc35c7a4a8fef55ce5c7695fbf88a9322cacb6feac",
  "contract/registry.js": "be2e3be63c04afc77941a2e851ecbf286a5f183e3e1fe4aedb8082b6e5a7fe13",
  "contract/resource-schema.js": "7a433024a1bafff529b0ce560d82ac88f42f9f7125409eb5a391f555fa93cfd7",
  "contract/session.js": "8aaf8e329676ce2cd87fbe9a13366f00807cdfd97704564830611c0b8cd2ec8f",
  "contract/state-schema.js": "ccea5b69726eb88ed568348b5707b987583cc0d92ce7d9a7ee7c5672266e8cfe",
  "contract/types.ts": "30908ca6dde7bb3ab6feed25c8d742287431c6467fb3e993c519b296cab55034",
  "contract/value.js": "c0da66bad54e30c952287ff6c5ae00b6d551b6ec69ddb6b2fb63c4a0b8186646",
  "index.js": "e34c25f5432c730d52a336b7be86bce1ea9e39b65b4b1cdd9a0cc0f1aef38ca8",
  "package.json": "10866a359098264739eb357f5b98fad22f85b08343799225b96b3cabfe558dba",
  "rules/legacy-three.js": "d201c401e3a9ff3d1427d16f1be304410fe60f91c911c1212bc38db5f1a3bc63",
  "scripts/fingerprint.mjs": "3c621367e4349d7704fb7b4234067c132504fc2e1bd66e6fa3024181e59bc94e",
  "scripts/run-tests.mjs": "a1ad5cbc3d7799f18eac02f1587d01d7d7960571ae3516f6a6483382db180c79",
  "test/contract.test.mjs": "bdbc5ea6f315e4af29c132e5976e3651c101d9d1773a8123c43e586ab6b316fa",
  "test/host.mjs": "d0830ad499231f57c640840de56864acfae0fabf75463732acda4f93149d9be0",
  "test/probes.mjs": "a374c25f89cbf253190b409572e5ec5e2a2495bcbc73746cac7c39def6b26a20"
};
