# @dotapk/heros — effects contract v2 vertical slice

Private review candidate. Frozen 46 heroes / 184 numeric definitions, with only
three executable public skills: Anti-Mage Blink, Anti-Mage Mana Void and Lion Hex.
The remaining abilities still execute privately while their authors migrate them.
This is not a complete public game or a publishable 46-hero rules release.

The package has no Engine, main loop, AI, input, physics, rounds, networking,
media, accounts or full-world checkpoint. Rules receive detached frozen actor
facts plus their declared named ports. The private host owns RNG/time and the
unique HP/MP/CD/control/movement commits. Public snapshots contain namespaces only.
The contract is for reviewed static modules, not untrusted dynamic JavaScript.

## v2 registration and source identity

Use `registerFactory(heroId, slot, {abiVersion: BATTLE_ABI, parameters, create})`.
`create({hero, definition, definitions, parameters})` captures the frozen data from
this registry. Group coefficient caches may use a WeakMap keyed by `definitions`.
All replacement factories compile against the same prospective definitions before
any registry mutation. Failed validation is atomic.

Every implementation requires `behaviorId`, `revision`, `requires`, `stateSchema`,
and the result of `codeIdentity(['rules/owned.js', ...])`. Paths must exist in the
actual generated package source manifest. Include the complete implementation's
transitive rule inputs; do not invent hashes or use Function.toString. Core contract
source digests also contribute to rulesHash. `prepack` fingerprints actual files;
`npm test` verifies every shipped digest. Bundling and minification preserve this
identity. The declared source is reviewed against its handler during integration.
This protocol cannot attest arbitrary functions supplied by a malicious caller.

Factory `parameters` must contain every execution-affecting captured configuration
outside the definitions. The registry freezes it, passes it to `create` and includes
it in rulesHash. Do not capture undeclared mutable settings or closures in a factory.
For example, pure damage 10 and 35 from the same source factory use
`parameters: {amount: 10}` / `{amount: 35}`, and obtain different rules hashes.
Unannotated implementations are rejected. The manifest and package SHA identify
reviewed build inputs; behavior ID/revision are not a substitute for source identity.

`replaceSkill` keeps the selected ability ID and requires its current revision.
Numeric types, finite bounds, consumed keys, enums, timing/resource ranges and
implemented-skill dependencies are validated before host resource admission.
Factories validate any additional cross-coefficient constraints they consume.

## Canonical namespace schemas

Create one `defineStateSchema({id, version, schema, parameters, refinement})` object
for each shared namespace and reuse that exact canonical object across its hooks
and skills. JSON schemas support closed objects, bounded arrays, numeric/string
bounds and anyOf. Stateless rules use `EMPTY_STATE_SCHEMA`. Optional pure
`refinement` has its own source identity and declared parameters; it does not
replace the declarative shape. Do not capture undeclared validator configuration.

Implementations declare `stateSchema`, not arbitrary `validateState` or stateVersion.
The registry rejects two shared namespace schemas with different identity, version,
hash or validator object, even if captured functions have the same source text.
Writes and restores use the same central namespace validator. All restores
prevalidate before touching state; private world restores validate rules first.

`createRuleSession(sealed).invoke(heroId,slot,hook,host,event)` returns handled/value.
The host supplies now(), actor(id), random() and finite named ports. It must not
pass a mutable Engine, fighter façade, raw input or catch-all mutation API.

Port families are declared in contract/types.ts. The private three-skill host
implements damage, control.apply, motion, protect, target.route and cue. Additional
ports remain integration blockers until implemented and parity-tested privately.
The public TestHost has fixed geometry and resource transactions only.

## Validation and release status

`npm test` on Node 22+ executes the shipped contract suite and fixtures, verifies
source fingerprints and fails if fewer than 29 tests execute. Both the source
package and the exact installed tarball must pass. Removing tests cannot yield a
zero-test green result. No install lifecycle regenerates or downloads anything.

ABI: `heros-effects-2`. Public GitHub/npm release and production deployment remain
blocked until all 46 implementations, private regressions, real browser QA and
independent final boundary review pass.
