// Generated from actual package source files; no Function.toString identity.
export const sourceManifest={
  "content/heroes.json": "b837cb0c5c601092c7ce1b0d2fda6a90bcde8b6d797149cbac9cc9cf3d381b7d",
  "content/index.js": "e552bf8888a58f1c171e430e36a4767157eaf43d717cd7b3195d3a8643cf85e1",
  "contract/code-identity.js": "b211e83f16c3aa84e79b1d5e2fdb36c33a4e55a329e45f357496f8402340d3f8",
  "contract/definition-schema.js": "d74ca7e96fa1853fbeb3e67e6f01d2690c85143e7ef0ab31bd4dd808cae10a78",
  "contract/registry.js": "f45b8cf2a65f2fc79b404f274173dbef00d273bbe4c544df7dc70c8f92c1b597",
  "contract/session.js": "52ef41303c6f2a23695194a4ed1fb302c11fe94a280d5b57c767630e0c66bf23",
  "contract/state-schema.js": "ccea5b69726eb88ed568348b5707b987583cc0d92ce7d9a7ee7c5672266e8cfe",
  "contract/types.ts": "913df61265975c3494e2ee243a5aa9d252177084ded663712bfcd6e8335b2e40",
  "contract/value.js": "c0da66bad54e30c952287ff6c5ae00b6d551b6ec69ddb6b2fb63c4a0b8186646",
  "index.js": "e34c25f5432c730d52a336b7be86bce1ea9e39b65b4b1cdd9a0cc0f1aef38ca8",
  "package.json": "17ae2a76b63e32d45296ce0633563cf64eaec8ef25229a196275771f9c58edb1",
  "rules/legacy-three.js": "d201c401e3a9ff3d1427d16f1be304410fe60f91c911c1212bc38db5f1a3bc63",
  "scripts/fingerprint.mjs": "3c621367e4349d7704fb7b4234067c132504fc2e1bd66e6fa3024181e59bc94e",
  "scripts/run-tests.mjs": "743c5e2d93d7ce182dd1dcb67c88b91b075901df29bed32fe59d645ea8e4123f",
  "test/contract.test.mjs": "8cff963e89b385c853faf22e1cc379c721af2f6ca6dd851064e1ecd380aeae7b",
  "test/host.mjs": "d0830ad499231f57c640840de56864acfae0fabf75463732acda4f93149d9be0",
  "test/probes.mjs": "a374c25f89cbf253190b409572e5ec5e2a2495bcbc73746cac7c39def6b26a20"
};
