# Cleave arena parameter boundary

Cleave (numeric hero 12, slot 1) preserves the existing arena adaptation: an enabled passive ends selected hostile wards in the target's forward half-plane after a basic-hit receipt, including `landed: false`. It causes no extra hero damage and adds no summon behavior.

|Input|Support|
|---|---|
|Factory `wardForwardRangeWu`|Effective ward-selection parameter. Default 330; finite number in [0,1200] arena world units. Selects `distanceToTarget < wardForwardRangeWu`, with no fighter-radius padding. Zero selects no wards; the exact boundary is excluded.|
|Definition `mvp.damage` = 90|Display metadata for this adaptation; not a damage balance input. A different value is explicitly rejected at factory compilation/definition replacement.|
|Definition `mvp.radius_wu` = 385.00000000000006|Display metadata for this adaptation; not the effective ward range. A different value is explicitly rejected. There is no radius-to-range conversion.|
|Definition `mvp.passive` = true|Fixed passive admission; changing it is rejected.|
|Other Cleave definition numeric/official fields|Roster metadata for this ward-selection rule, not advertised executable ward balance parameters. The frozen definition validator still applies.|
|Other factory option keys|Rejected. Factory range is valid only for Cleave; group registration directs it only to 12/1.|

`CLEAVE_PARAMETER_SUPPORT` exports the effective range bounds and the three explicitly fixed field roles. The factory's canonical parameters and manifest `executionParameters` contain the actual range; it participates in `rulesHash`. Cleave revision is `1.1.0`. Namespace and canonical empty state schema are unchanged. All five transitive rule files remain in code identity; changes to the two common files also change identities of other handlers that declare those files. Old incompatible snapshots must be rejected.

```js
const host = {hostSemantics: EVENT_VERSION, hostCapabilities: supportedCapabilities};
registerRemainingLegacy10To19(registry, {...host, wardForwardRangeWu: 330});
registry.replaceSkill(12, 1, {
  definition: registry.definition(12).abilities[1],
  factory: remainingLegacyFactory(12, 1, {...host, wardForwardRangeWu: 20}),
}, {abilityId: 'sven_cleave', revision: '1.1.0'});
```

Supply only native-confirmed capabilities. The existing default gate is retained. Parameter configuration does not add host capability support.

At a live hostile ward 150 units forward from the target, 330 selects one end command and 20 selects none. Owner, forward direction, passive-break checks, existing command profile, logs, presentation and hit-stage ordering remain unchanged. The host consumes those finite commands through its existing ward-ending path. Tests here are controlled command/consumer harnesses, including mirrored actor identities, definition-rejection atomicity and snapshot incompatibility; native input verification belongs to the private bridge integrator.

Run `node scripts/legacy-10-19/run-cleave-p2-tests.mjs` for the focused shipped tests.
