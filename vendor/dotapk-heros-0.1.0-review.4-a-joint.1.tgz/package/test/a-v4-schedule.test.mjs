import test from 'node:test';import assert from 'node:assert/strict';
import {heroes,createHeroRegistry,createRuleSession} from '../index.js';
import {registerA,A_HERO_IDS} from '../rules/a/register.js';import {aHost} from './a-host.mjs';
import {replacementFactory} from './a-probes.mjs';
function setup(id,slot,definitions=heroes,enemy=3){const sealed=registerA(createHeroRegistry(definitions)).seal(),session=createRuleSession(sealed),f=aHost(id,enemy,sealed.definitions),a=sealed.hero(id).abilities[slot],cast={owner:0,target:1,abilityId:a.id,slot,castId:'harness:typed-cast',direction:1,aimX:650,heldSeconds:0,reflected:false};return {sealed,session,f,a,cast,id,slot};}
const invoke=(s,hook,event=s.cast)=>s.session.invoke(s.id,s.slot,hook,s.f.host,event).value;
const activate=s=>invoke(s,'activate');const tick=s=>s.f.deliverNext(s.session,s.id,s.slot);
const state=s=>s.session.snapshot().namespaces.find(x=>x.namespace==='heros/a/'+s.a.id)?.state;
const remove=(s,target,tier='basic')=>{for(const handle of s.f.host.ports.status.cleanse(target,tier))invoke(s,'onStage',{kind:'status-removed',handle});};
function hostilePeriodicDefinitions(){
 // Explicit harness recipe variant to exercise target!=source status; production content stays byte-identical.
 const defs=structuredClone(heroes),a=defs.find(h=>h.registryNumericId===55).abilities[0];
 a.recipe={target:'enemy',ops:[{op:'status',duration:4,values:{},tick:{interval:1,ops:[{op:'heal',amount:10}]}}]};return defs;
}
test('A typed handler manifests declare only actual source recipe pairs and are immutable',()=>{
 const s=registerA(createHeroRegistry()).seal();for(const id of A_HERO_IDS)for(let slot=0;slot<4;slot++){const impl=s.implementation(id,slot);if(impl.scheduledBindings)for(const [name,pairs] of Object.entries(impl.scheduledBindings)){assert.equal(typeof impl.scheduledHandlers[name],'function');assert(Object.isFrozen(pairs));assert(Object.isFrozen(pairs[0]));}}
 assert.deepEqual(s.implementation(55,1).scheduledBindings,{statusPulse:[{binding:'status',delivery:'actor.status-advance'}]});
 assert.deepEqual(s.implementation(50,0).scheduledBindings,{delayedProgram:[{binding:'source-job',delivery:'pack.job-due'}]});
 assert.deepEqual(s.implementation(50,1).scheduledBindings,{areaPulse:[{binding:'entity-area',delivery:'pack.entity'}]});
 assert.equal(s.implementation(50,2).scheduledBindings,null);assert.deepEqual(s.implementation(42,2).scheduledBindings,{});
});
test('A statusPulse initial registration uses the exact accepted status handle and attached target',()=>{
 const s=setup(55,1);activate(s);const row=state(s).records[0],job=s.f.scheduleRequests[0];assert.equal(job.binding.ref,row.handle);assert(s.f.statuses.has(row.handle));assert.equal(job.target,row.target);assert.equal(job.owner,row.owner);assert.equal(job.delivery,'actor.status-advance');assert.notEqual(job.binding.ref,String(row.n));
});
test('A statusPulse reschedule preserves its exact binding while ordinal data stays opaque',()=>{
 const s=setup(21,0);activate(s);const first=s.f.scheduleRequests[0];tick(s);const next=s.f.scheduleRequests[1];assert.deepEqual(next.binding,first.binding);assert.equal(next.target,first.target);assert.deepEqual(next.data,first.data);assert.equal(next.delivery,'actor.status-advance');
});
test('A Hammer four healing pulses include the terminal reference lease before removal',()=>{
 const s=setup(55,2);s.f.actors[0].hp=800;activate(s);const amount=90+s.sealed.hero(55).attack*.85;for(let n=0;n<4;n++)assert(tick(s));assert(Math.abs(s.f.actors[0].hp-(800+amount*.4))<1e-9);assert.equal(s.f.jobs.size,0);assert.equal(state(s).records.filter(x=>x.program).length,0);assert.equal(s.f.scheduleRequests.length,4);
});
test('A self-removing Nova upkeep cancels exact status binding without a residual reschedule',()=>{
 const s=setup(50,3);activate(s);s.f.actors[0].mp=10;tick(s);assert.equal(s.f.statuses.size,0);assert.equal(s.f.jobs.size,0);assert.equal(s.f.scheduleRequests.length,1);assert.equal(s.f.receipts.length,0);
});
test('A explicit dispel notification removes canonical record and cancels all jobs for that exact ref',()=>{
 const s=setup(21,0);activate(s);remove(s,0);assert.equal(s.f.jobs.size,0);assert.equal(state(s).records.length,0);assert.equal(tick(s),false);assert.equal(s.f.actors[0].hp,1000);
});
test('A refresh admits a new opaque handle, cancels old sequence, and leaves one canonical periodic record',()=>{
 const s=setup(55,1);activate(s);const old=s.f.scheduleRequests[0].binding.ref;activate(s);const fresh=s.f.scheduleRequests[1].binding.ref;assert.notEqual(old,fresh);assert(!s.f.statuses.has(old));assert.equal(s.f.jobs.size,1);assert.equal(state(s).records.length,1);assert.equal([...s.f.jobs.values()][0].binding.ref,fresh);
});
test('A stale remove and stale scheduled record cannot erase refreshed status or debit HP',()=>{
 const s=setup(21,0);activate(s);const old=state(s).records[0];activate(s);invoke(s,'onStage',{kind:'status-removed',handle:old.handle});s.session.scheduled(s.id,s.slot,'statusPulse',s.f.host,{record:old.n});assert.equal(state(s).records.length,1);assert.equal(s.f.actors[0].hp,1000);assert.equal(s.f.jobs.size,1);
});
test('A launched source job declares original target and survives ordinary interruption',()=>{
 const s=setup(28,0);activate(s);const job=s.f.scheduleRequests[0];assert.deepEqual(job.binding,{kind:'source-job'});assert.equal(job.target,1);assert.equal(job.owner,0);assert.equal(job.delivery,'pack.job-due');invoke(s,'onInterrupt',{owner:0});tick(s);assert.equal(s.f.receipts[0].actual,340);
});
test('A source job target death is not eager cancellation; due rejection cleans public pending state by explicit event',()=>{
 const s=setup(50,0);activate(s);s.f.actors[1].alive=false;s.f.actors[1].hp=0;invoke(s,'onDeath',{actor:1});assert.equal(s.f.jobs.size,1);assert.equal(state(s).jobs.length,1);tick(s);assert.equal(s.f.receipts.length,0);assert.equal(state(s).jobs.length,0);
});
test('A controlled training revival before source-job due remains distinct from reset',()=>{
 const s=setup(50,0);activate(s);s.f.actors[1].alive=false;s.f.actors[1].hp=0;invoke(s,'onDeath',{actor:1});s.f.actors[1].alive=true;s.f.actors[1].hp=1000;tick(s);assert.equal(s.f.receipts[0].actual,280);assert.equal(state(s).jobs.length,0);
});
test('A source death cancels launched source jobs and their public canonical rows',()=>{
 const s=setup(50,0);activate(s);s.f.actors[0].alive=false;s.f.actors[0].hp=0;invoke(s,'onDeath',{actor:0});assert.equal(s.f.jobs.size,0);assert.equal(state(s).jobs.length,0);assert.equal(tick(s),false);
});
test('A Scythe delay is independent of its strong-dispellable stun status',()=>{
 const s=setup(36,3);activate(s);remove(s,1,'strong');assert.equal(s.f.jobs.size,1);s.f.actors[1].hp=800;tick(s);assert.equal(s.f.receipts[0].actual,200*s.a.mvp.params.damage_per_health);
});
test('A area binding uses an actual declared legacyEffect admission handle and finite original profile',()=>{
 const s=setup(50,1);activate(s);const row=state(s).areas[0],job=s.f.scheduleRequests[0],entity=s.f.entities.get(row.handle);assert(entity);assert.equal(entity.spec.kind,'area');assert.equal(entity.spec.duration,s.a.mvp.params.AbilityDuration);assert.equal(entity.spec.data.interval,s.a.mvp.params.AbilityDuration/s.a.mvp.params.num_explosions);assert.equal(entity.spec.data.follow,true);assert.deepEqual(job.binding,{kind:'entity',mode:'area',ref:row.handle});assert.equal(job.delivery,'pack.entity');assert.equal(job.target,1);
});
test('A ordinary native area remains independent of associated status dispel',()=>{
 const s=setup(32,1);activate(s);remove(s,0);assert.equal(s.f.entities.size,1);assert.equal(s.f.jobs.size,1);tick(s);assert.equal(s.f.receipts[0].actual,s.a.mvp.params.damage);
});
test('A source death ends actual native area references and cleans canonical state',()=>{
 const s=setup(50,1);activate(s);s.f.actors[0].alive=false;s.f.actors[0].hp=0;invoke(s,'onDeath',{actor:0});assert.equal(s.f.entities.size,0);assert.equal(s.f.jobs.size,0);assert.equal(state(s).areas.length,0);
});
test('A native area admission never invents an entity ref from job data or accepts a missing handle',()=>{
 const s=setup(50,1);s.f.host.ports.legacyEffect.spawn=()=>null;assert.throws(()=>activate(s),/A-ENTITY-14/);assert.equal(s.f.jobs.size,0);assert.equal(s.session.snapshot().namespaces.length,0);assert.equal(s.f.receipts.length,0);
});
test('A area canonical snapshot requires accepted reference and survives roundtrip; missing ref rejects atomically',()=>{
 const s=setup(50,1);activate(s);const snap=s.session.snapshot();s.session.restore(snap);const forged=structuredClone(snap);delete forged.namespaces[0].state.areas[0].handle;assert.throws(()=>s.session.restore(forged));assert.deepEqual(s.session.snapshot(),snap);invoke(s,'onStage',{kind:'effect-end',handle:state(s).areas[0].handle});assert.equal(state(s).areas.length,0);
});
test('A posthumous target status retains typed source!=target ownership and continues healing in explicit harness recipe variant',()=>{
 const s=setup(55,0,hostilePeriodicDefinitions());s.f.actors[1].hp=800;activate(s);const baseline=s.f.actors[1].hp,periodic=state(s).records.find(x=>x.program);assert.equal(periodic.target,1);assert.equal(periodic.owner,0);s.f.actors[0].hp=0;s.f.actors[0].alive=false;invoke(s,'onDeath',{actor:0});assert(s.f.statuses.has(periodic.handle));assert.equal(s.f.jobs.size,1);tick(s);assert(s.f.actors[1].hp>baseline);assert.equal(s.f.actors[0].hp,0);assert.equal(s.f.scheduleRequests.at(-1).owner,0);
});
test('A suppressed hostile status pulse retains clock and binding; restoring immunity does not catch up; diagnostic charge guard remains exercised',()=>{
 const s=setup(55,0,hostilePeriodicDefinitions());s.f.actors[1].hp=800;activate(s);const before=s.f.actors[1].hp;s.f.actors[1].debuffImmune=true;tick(s);assert.equal(s.f.actors[1].hp,before);assert.equal(s.f.jobs.size,1);s.f.actors[1].debuffImmune=false;tick(s);assert(s.f.actors[1].hp>before);
 const defs=structuredClone(heroes),a=defs.find(h=>h.registryNumericId===50).abilities[2];a.mvp.charges=2;a.mvp.charge_restore_s=1;
 const charged=setup(50,2,defs),p=invoke(charged,'planCast',{...charged.cast,actionReady:true,manaAvailable:charged.f.actors[0].mp,cooldownRemaining:0,chargesAvailable:0});assert.equal(p.reason,'charges');assert.equal(charged.f.requests.length,0);
});

// Batch10: real public registry/session, explicit unit harness facts, never Engine/input evidence.
let batch10Sealed;
function bt(id,slot,side=0,sealed=batch10Sealed??=registerA(createHeroRegistry()).seal()){
 const session=createRuleSession(sealed),f=aHost(id,id,sealed.definitions),a=sealed.hero(id).abilities[slot];
 return {id,slot,sealed,session,f,a,cast:{owner:side,target:1-side,abilityId:a.id,slot,castId:'harness:batch10',direction:side?-1:1,aimX:f.actors[1-side].x,heldSeconds:0,reflected:false}};
}
const btFacts=(s,range)=>({...s.cast,actionReady:true,manaAvailable:s.f.actors[s.cast.owner].mp,cooldownRemaining:0,chargesAvailable:4,...(range!==undefined?{effectiveCastRange:range}:{})});
const distance=(s,n)=>{s.f.actors[0].x=45;s.f.actors[1].x=45+n;s.cast.aimX=s.f.actors[s.cast.target].x;};
const hammer='omniknight_hammer_of_purity',slowId=hammer+':recipe.ops.1',healId=hammer+':recipe.ops.2';
test('batch10 only 47/0,47/1 opt into effective range; only55/2 opts into immutable source status declarations',()=>{
 const s=bt(55,2);for(const id of A_HERO_IDS)for(let slot=0;slot<4;slot++){
  const impl=s.sealed.implementation(id,slot);assert.equal(!!impl.requiredCastFacts,id===47&&slot<2);assert.equal(!!impl.statusDeclarations,id===55&&slot===2);
  assert.equal(impl.revision,id===47&&slot<2||id===55&&slot===2||id===50&&slot===3?'2.2.0':'2.1.0');
 }
 assert.deepEqual(s.sealed.implementation(55,2).statusDeclarations,[
  {id:slowId,key:hammer,recipient:'enemy',duration:.2,interval:0,programId:null,schedule:null,polarity:'negative',dispel:'basic',pierces:false,values:{moveSlow:.75}},
  {id:healId,key:hammer,recipient:'self',duration:4,interval:1,programId:hammer+':recipe.ops.2.tick.ops',schedule:{handler:'statusPulse',binding:'status',delivery:'actor.status-advance'},polarity:'positive',dispel:'basic',pierces:false,values:{}}
 ]);
 assert(Object.isFrozen(s.sealed.implementation(55,2).statusDeclarations[1].schedule));
});
for(const slot of [0,1])for(const side of [0,1])test(`batch10 47/${slot} side${side} accepts supplied form range at bridge-reported distance and rejects base scalar without resource/state commit`,()=>{
 const s=bt(47,slot,side),effective=slot===0?742.5:275,n=slot===0?677.9166666666666:253.4166666666666;distance(s,n);
 const actors=structuredClone(s.f.actors),snap=s.session.snapshot();assert.equal(invoke(s,'planCast',btFacts(s,effective)).accepted,true);assert.equal(invoke(s,'planCast',btFacts(s,s.a.mvp.range_wu)).reason,'target');assert.deepEqual(s.f.actors,actors);assert.deepEqual(s.session.snapshot(),snap);assert.equal(s.f.requests.length,0);
});
for(const slot of [0,1])for(const side of [0,1])for(const eps of [-1e-6,0,1e-6])test(`batch10 47/${slot} side${side} effective+22 exact boundary ${eps}`,()=>{
 const s=bt(47,slot,side),range=slot===0?742.5:275;distance(s,range+22+eps);assert.equal(invoke(s,'planCast',btFacts(s,range)).accepted,eps<=0);
});
for(const slot of [0,1])for(const side of [0,1])test(`batch10 47/${slot} side${side} zero and reduced supplied range remain literal, never synthesized from base`,()=>{
 const s=bt(47,slot,side);distance(s,22);assert.equal(invoke(s,'planCast',btFacts(s,0)).accepted,true);distance(s,22+1e-5);assert.equal(invoke(s,'planCast',btFacts(s,0)).accepted,false);
 const reduced=(s.a.mvp.range_wu+192.5)*.5;distance(s,reduced+22);assert.equal(invoke(s,'planCast',btFacts(s,reduced)).accepted,true);distance(s,reduced+22+1e-5);assert.equal(invoke(s,'planCast',btFacts(s,reduced)).accepted,false);
});
for(const slot of [0,1])for(const [name,edit] of [
 ['missing',x=>delete x.effectiveCastRange],['NaN',x=>x.effectiveCastRange=NaN],['negative',x=>x.effectiveCastRange=-1],['overflow',x=>x.effectiveCastRange=1e7+1],['wrong slot',x=>x.slot=3],['wrong ability',x=>x.abilityId='foreign'],['wrong owner',x=>x.owner=2],['wrong target',x=>x.target=null]
])test(`batch10 47/${slot} rejects ${name} range fact before handler/host effects`,()=>{
 const s=bt(47,slot),f=btFacts(s,742.5),before=s.session.snapshot(),actors=structuredClone(s.f.actors);edit(f);assert.throws(()=>invoke(s,'planCast',f));assert.deepEqual(s.session.snapshot(),before);assert.deepEqual(s.f.actors,actors);assert.equal(s.f.requests.length,0);
});
for(const slot of [0,1])for(const side of [0,1])test(`batch10 47/${slot} side${side} activation retains existing routing; no effective-fact re-admission`,()=>{
 const s=bt(47,slot,side);distance(s,60);assert.equal(invoke(s,'planCast',btFacts(s,275)).accepted,true);distance(s,900);activate(s);assert.equal(s.f.receipts.length,1);
 const bad=bt(47,slot,side);assert.throws(()=>invoke(bad,'activate',{...bad.cast,effectiveCastRange:275}),/misplaced/);assert.equal(bad.f.requests.length,0);
});
for(const side of [0,1])test(`batch1055/2 side${side} real status requests/records and initial/requeued pulses retain two IDs and native key`,()=>{
 const s=bt(55,2,side);s.f.actors[side].hp=800;activate(s);const rows=state(s).records,requests=[...s.f.statuses.values()].map(x=>x.spec);
 assert.deepEqual(rows.map(x=>x.statusDeclarationId),[slowId,healId]);assert.deepEqual(requests.map(x=>x.key),[hammer,hammer]);assert.equal(rows[0].target,1-side);assert.equal(rows[1].target,side);assert.equal(rows[1].program,hammer+':recipe.ops.2.tick.ops');
 const first=s.f.scheduleRequests[0];assert.equal(first.statusDeclarationId,healId);assert.equal(first.binding.ref,rows[1].handle);assert.equal(first.target,side);tick(s);assert.equal(s.f.scheduleRequests[1].statusDeclarationId,healId);assert.equal(s.f.scheduleRequests[1].binding.ref,first.binding.ref);
});
for(const side of [0,1])test(`batch1055/2 side${side} reflection uses explicitly routed effective owner/target without ID/key override`,()=>{
 const s=bt(55,2,side);s.f.actors[1-side].counter=true;s.f.actors[1-side].hp=800;activate(s);const rows=state(s).records;assert.equal(rows[0].owner,1-side);assert.equal(rows[0].target,side);assert.equal(rows[0].statusDeclarationId,slowId);assert.equal(rows[1].owner,1-side);assert.equal(rows[1].target,1-side);assert.equal(rows[1].statusDeclarationId,healId);const hp=s.f.actors[1-side].hp;tick(s);assert(s.f.actors[1-side].hp>hp);assert.equal(s.f.actors[side].hp,1000-s.f.receipts[0].actual);
});
for(const side of [0,1])test(`batch1055/2 side${side} enemy death preserves separate self timer; source death terminates its own timer`,()=>{
 const s=bt(55,2,side);s.f.actors[side].hp=800;activate(s);s.f.actors[1-side].hp=0;s.f.actors[1-side].alive=false;invoke(s,'onDeath',{actor:1-side});assert.equal(state(s).records.length,1);assert.equal(state(s).records[0].statusDeclarationId,healId);tick(s);assert(s.f.actors[side].hp>800);s.f.actors[side].hp=0;s.f.actors[side].alive=false;invoke(s,'onDeath',{actor:side});assert.equal(s.f.jobs.size,0);assert.equal(state(s).records.length,0);
});
test('batch1055/2 parameter replacement rederives source duration/value/cadence declarations, records and hash',()=>{
 const r=registerA(createHeroRegistry()),old=r.definition(55).abilities[2];r.replaceSkill(55,2,{definition:{...old,mvp:{...old.mvp,params:{...old.mvp.params,duration:.6,heal_duration:6,total_ticks:3,movement_slow:40}}}},{abilityId:old.id,revision:'2.2.0'});const changed=r.seal(),s=bt(55,2,0,changed),table=changed.implementation(55,2).statusDeclarations;
 assert.equal(table[0].duration,.6);assert.deepEqual(table[0].values,{moveSlow:.4});assert.equal(table[1].duration,6);assert.equal(table[1].interval,2);assert.notEqual(changed.rulesHash,bt(55,2).sealed.rulesHash);activate(s);assert.equal(state(s).records[1].interval,2);assert.equal(s.f.scheduleRequests[0].delay,2);
});
test('batch1055/2 heal_pct60 changes actual public credits and pure handler35 still executes once',()=>{
 const r=registerA(createHeroRegistry()),old=r.definition(55).abilities[2];r.replaceSkill(55,2,{definition:{...old,mvp:{...old.mvp,params:{...old.mvp.params,heal_pct:60}}}},{abilityId:old.id,revision:'2.2.0'});const s=bt(55,2,0,r.seal());s.f.actors[0].hp=800;activate(s);const amount=s.f.receipts[0].actual;for(let n=0;n<4;n++)tick(s);assert(Math.abs(s.f.actors[0].hp-(800+amount*.6))<1e-9);
 const other=registerA(createHeroRegistry()),a=other.definition(55).abilities[2];other.replaceSkill(55,2,{definition:a,factory:replacementFactory(35)},{abilityId:a.id,revision:'2.2.0'});const p=bt(55,2,0,other.seal());p.f.actors[0].hp=800;activate(p);assert.equal(p.f.actors[0].hp,835);assert.equal(p.f.requests.filter(x=>x.amount===35).length,1);assert.equal(p.f.jobs.size,0);
});
test('batch1055/2 two-domain mirror replacement keeps original same-target native-key refresh behavior',()=>{
 const s=bt(55,2);activate(s);const oldRefs=state(s).records.map(x=>x.handle);invoke(s,'activate',{...s.cast,owner:1,target:0,aimX:450});const rows=state(s).records;assert.equal(rows.length,2);assert(rows.every(x=>x.owner===1));assert.equal(s.f.jobs.size,1);assert(oldRefs.every(h=>!s.f.statuses.has(h)));assert.equal(rows.find(x=>x.statusDeclarationId===healId).target,1);
});
test('batch1055/2 refresh/dispel cancels only accepted ID/ref; stale replay cannot heal twice or remove replacement',()=>{
 const s=bt(55,2);s.f.actors[0].hp=800;activate(s);const old=state(s).records.find(x=>x.program);activate(s);const current=state(s).records.find(x=>x.program),before=s.f.actors[0].hp;
 s.session.scheduled(55,2,'statusPulse',s.f.host,{record:old.n});invoke(s,'onStage',{kind:'status-removed',handle:old.handle});assert.equal(s.f.actors[0].hp,before);assert.equal(state(s).records.find(x=>x.program).handle,current.handle);remove(s,0);assert.equal(s.f.jobs.size,0);assert(!state(s).records.some(x=>x.program));
});
test('batch1055/2 enemy debuff immunity suppresses only hostile status while self declaration and healing remain',()=>{
 const s=bt(55,2);s.f.actors[0].hp=800;s.f.actors[1].debuffImmune=true;activate(s);assert.equal(state(s).records.length,1);assert.equal(state(s).records[0].statusDeclarationId,healId);tick(s);assert(s.f.actors[0].hp>800);
});
test('batch1055/2 invulnerability preserves original whole-route rejection and post-route component admission separately',()=>{
 const denied=bt(55,2);denied.f.actors[1].invulnerable=true;assert.equal(activate(denied).accepted,false);assert.equal(denied.f.statuses.size,0);
 const admitted=bt(55,2),damage=admitted.f.host.ports.damage;admitted.f.actors[0].hp=800;
 // Explicit harness immunity transition AFTER routed damage, not a native input claim.
 admitted.f.host.ports.damage=spec=>{const receipt=damage(spec);admitted.f.actors[1].invulnerable=true;return receipt;};activate(admitted);assert.deepEqual(state(admitted).records.map(x=>x.statusDeclarationId),[healId]);
});
for(const [name,edit] of [
 ['ID missing',r=>delete r.statusDeclarationId],['ID wrong',r=>r.statusDeclarationId=slowId],['program foreign',r=>r.program='arbitrary'],['interval foreign',r=>r.interval=.25],['owner-domain foreign',r=>r.owner=1],['target-domain foreign',r=>r.target=1],['source values foreign',r=>r.values={healAmp:100}],['life foreign',r=>r.expires+=1],['key foreign',r=>r.key='renamed'],['polarity foreign',r=>r.polarity='negative']
])test('batch1055/2 honest canonical restore roundtrips; '+name+' rejects atomically',()=>{
 const s=bt(55,2);activate(s);const before=s.session.snapshot();s.session.restore(before);const forged=structuredClone(before),row=forged.namespaces[0].state.records.find(x=>x.program);edit(row);assert.throws(()=>s.session.restore(forged));assert.deepEqual(s.session.snapshot(),before);
});
test('batch1055/2 canonical n and opaque handle remain unique across two declared records; malformed duplicates reject',()=>{
 const s=bt(55,2);activate(s);const before=s.session.snapshot();for(const key of ['n','handle']){const x=structuredClone(before);x.namespaces[0].state.records[1][key]=x.namespaces[0].state.records[0][key];assert.throws(()=>s.session.restore(x));assert.deepEqual(s.session.snapshot(),before);}
});
test('batch1055/2 same-domain source recipe ambiguity rejects registration rather than bypassing old identity guard',()=>{
 const defs=structuredClone(heroes),a=defs.find(h=>h.registryNumericId===55).abilities[2];a.recipe.ops[2].to='enemy';assert.throws(()=>registerA(createHeroRegistry(defs)),/Ambiguous status declaration/);
});
