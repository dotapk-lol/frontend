import {testHost} from './host.mjs';
import {heroes} from '../index.js';
/** Explicit harness fixtures and named callback delivery. No match/input/AI/physics. */
export function aHost(heroId,enemyId=3,definitions=heroes){
 const f=testHost([heroId,enemyId]);let time=0,seq=0;
 // Actual declared production ceilings; full MP matches native initial resources.
 // HP/positions remain explicit bounded harness fixtures, not natural-match evidence.
 for(const actor of f.actors){const hero=definitions.find(h=>h.registryNumericId===actor.heroId);if(!hero)throw Error('Unknown A fixture hero');const maxMp=hero.combatMana??hero.mana??1200;if(!Number.isFinite(maxMp)||maxMp<=0)throw Error('Invalid declared fixture ceiling');actor.maxMp=maxMp;actor.mp=maxMp;}
 const statuses=new Map(),jobs=new Map(),entities=new Map(),debts=[],scheduleRequests=[];
 // Explicit harness lifecycle receipts. Handles never reuse; production dispatch is bridge-owned.
 const cancelReference=ref=>{for(const [handle,job] of jobs)if(job.binding?.ref===ref)jobs.delete(handle);};
 const removeStatus=handle=>{cancelReference(handle);return statuses.delete(handle);};
 f.host.now=()=>time;
 f.host.ports.status={
  apply(spec){const actor=f.actors[spec.target];f.requests.push(spec);if(!actor.alive||actor.invulnerable||spec.polarity==='negative'&&actor.debuffImmune&&!spec.pierces)return null;
   const handle='status:'+ ++seq;statuses.set(handle,{spec,expires:time+spec.duration});return handle;},
  remove:removeStatus,
  query(target,key){return [...statuses.values()].filter(x=>x.spec.target===target&&x.spec.key===key&&x.expires>=time-1e-8).map(x=>x.spec);},
  cleanse(target,tier){const handles=[];for(const [handle,x] of statuses)if(x.spec.target===target&&x.spec.dispel!=='none'&&(tier==='strong'||x.spec.dispel==='basic')){removeStatus(handle);handles.push(handle);}return handles;}
 };
 f.host.ports.legacyEffect={
  spawn(spec){f.requests.push(spec);const handle='entity:'+ ++seq;entities.set(handle,{spec,expires:time+spec.duration});return handle;},
  view(handle){const x=entities.get(handle);return x?{alive:time<=x.expires+1e-8,x:x.spec.x,y:0}:null;},
  end(handle,reason){cancelReference(handle);return entities.delete(handle);}
 };
 f.host.ports.schedule=spec=>{if(!spec.binding||!Object.hasOwn(spec,'target')||!spec.delivery)throw Error('Harness A requires explicit typed schedule');scheduleRequests.push(spec);
  if(spec.binding?.kind==='status'){const x=statuses.get(spec.binding.ref);if(!x||x.spec.owner!==spec.owner||x.spec.target!==spec.target||x.spec.abilityId!==spec.abilityId)throw Error('Harness rejects foreign/stale status reference');}
  if(spec.binding?.kind==='entity'){const x=entities.get(spec.binding.ref);if(!x||x.spec.owner!==spec.owner||x.spec.data.target!==spec.target||x.spec.abilityId!==spec.abilityId)throw Error('Harness rejects foreign/stale entity reference');}
  const handle='job:'+ ++seq;jobs.set(handle,{...spec,due:time+spec.delay});return handle;};
 f.host.ports.cancelJob=handle=>jobs.delete(handle);
 f.host.ports.mana=spec=>{f.requests.push(spec);const actor=f.actors[spec.actor],before=actor.mp;actor.mp=Math.max(0,Math.min(actor.maxMp,before+spec.delta));return actor.mp-before;};
 f.host.ports.transferMana=spec=>{f.requests.push(spec);const source=f.actors[spec.source],target=f.actors[spec.target],amount=Math.min(source.mp,spec.requested);source.mp-=amount;target.mp=Math.min(target.maxMp,target.mp+amount);return amount;};
 f.host.ports.selfDamage=spec=>{f.requests.push(spec);const actor=f.actors[spec.actor],before=actor.hp;actor.hp=Math.max(spec.nonlethal?1:0,before-spec.amount);actor.alive=actor.hp>0;return {accepted:true,landed:true,guarded:false,raw:spec.amount,actual:before-actor.hp,deferred:0,killedAtDebit:before>0&&!actor.alive};};
 f.host.ports.deferredHP={begin(spec){debts.push(spec);return 'debt:'+debts.length;},settle(){throw Error('Harness settlement not implemented; private ledger owns repayment');}};
 f.host.ports.target.route=spec=>{const target=f.actors[spec.target];if(!target.alive||target.invulnerable)return {accepted:false,reason:'target',owner:spec.owner,target:spec.target,originalOwner:spec.owner,reflected:spec.reflected,noReflect:spec.reflected,noLifesteal:spec.reflected};
  const reflected=!!target.counter&&spec.reflectable&&!spec.reflected;if(reflected)target.counter=false;
  return {accepted:true,reason:null,owner:reflected?spec.target:spec.owner,target:reflected?spec.owner:spec.target,originalOwner:spec.owner,reflected:spec.reflected||reflected,noReflect:spec.reflected||reflected,noLifesteal:spec.reflected||reflected};};
 return {...f,statuses,jobs,entities,debts,scheduleRequests,setTime(t){if(t<time)throw Error('Harness time cannot reverse');time=t;},
  deliverNext(session,id,slot){const entry=[...jobs].sort((a,b)=>a[1].due-b[1].due)[0];if(!entry)return false;const [handle,job]=entry;jobs.delete(handle);time=Math.max(time,job.due);
   const kind=job.binding?.kind;
   if(kind==='status'&&(!statuses.has(job.binding.ref)||!f.actors[job.target].alive))return true;
   if(kind==='source-job'&&(!f.actors[job.owner].alive||!f.actors[job.target].alive)){session.invoke(id,slot,'onStage',f.host,{kind:'job-ended',handle});return true;}
   if(kind==='entity'&&(!entities.has(job.binding.ref)||!f.actors[job.owner].alive))return true;
   // Terminal references remain visible DURING callback; this is an explicit harness lease.
   session.scheduled(id,slot,job.handler,f.host,job.data);
   for(const [ref,x] of statuses)if(x.expires<=time+1e-8){removeStatus(ref);session.invoke(id,slot,'onStage',f.host,{kind:'status-removed',handle:ref});}
   return true;}};
}
