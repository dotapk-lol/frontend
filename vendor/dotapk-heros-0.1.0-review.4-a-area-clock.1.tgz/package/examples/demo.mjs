// A detached example invocation; this is not a game loop or native host.
import {createHeroRegistry,createRuleSession} from '../index.js';
import {installBlinkRange} from './blink-range.js';import {testHost} from '../test/host.mjs';
const registry=installBlinkRange(createHeroRegistry(),{rangeScale:.5}),sealed=registry.seal(),session=createRuleSession(sealed),fixture=testHost();
session.invoke(5,1,'activate',fixture.host,{owner:0,target:1,castId:'example:1',direction:1});
console.log(JSON.stringify({example:'blink-range',destinationX:fixture.actors[0].x,rulesHash:sealed.rulesHash}));
