// HARNESS: resource transactions and manually delivered lifecycle facts only.
// No match loop, collision, input, AI, or production host implementation.
import {heroes} from '../index.js';
export function bHost(heroId=57,owner=0,roll=.99,definitions=heroes){
 const actors=[0,1].map(id=>({id,heroId:id===owner?heroId:5,hp:1000,maxHp:2000,mp:1000,maxMp:1200,x:id?700:500,y:0,dir:id?-1:1,alive:true,invulnerable:false,debuffImmune:false,passivesEnabled:true,guarding:false,rooted:false,silenced:false}));
 // Registry-declared resources; this fixture is not native-host evidence.
 for(const actor of actors){const definition=definitions.find(h=>h.registryNumericId===actor.heroId);if(!definition)throw Error('Unknown B fixture hero');actor.maxMp=definition.combatMana??definition.mana??1200;actor.mp=actor.maxMp;}
 let time=0,sequence=0;const requests=[],receipts=[],rows=[],jobs=[],areas=[],controls=[];
 const record=(op,spec)=>requests.push({op,...spec});
 const enabled=s=>{const t=actors[s.target];return t.alive&&!t.invulnerable&&(s.polarity==='positive'||s.pierces||!t.debuffImmune);};
 const host={now:()=>time,actor:id=>actors[id],random:()=>roll,ports:{
 damage(s){record('damage',s);const t=actors[s.target],accepted=t.alive&&!t.invulnerable,guarded=t.guarding&&!s.dot&&s.blockable!==false,before=t.hp,raw=s.amount;t.hp-=Math.min(before,accepted?(guarded?Math.min(raw*.2,Math.max(0,before-1)):raw):0);t.alive=t.hp>0;const r={accepted,landed:accepted&&!guarded,guarded,raw,actual:before-t.hp,deferred:0,killedAtDebit:before>0&&!t.alive};receipts.push(r);return r;},
 heal(s){record('heal',s);const t=actors[s.target],actual=t.alive?Math.min(s.amount,t.maxHp-t.hp):0;t.hp+=actual;return{actual,deferred:0};},
 selfDamage(s){record('self-damage',s);const t=actors[s.actor],before=t.hp;t.hp=Math.max(s.nonlethal?1:0,t.hp-s.amount);t.alive=t.hp>0;return{actual:before-t.hp};},
 status:{apply(s){record('status',s);if(!enabled(s))return null;const i=rows.findIndex(r=>r.target===s.target&&r.key===s.key);if(i>=0)rows.splice(i,1);const r={...s,handle:'status:'+ ++sequence};rows.push(r);return r.handle;},query(target,key){return rows.filter(r=>r.target===target&&(key===undefined||r.key===key));},remove(handle){record('remove',{handle});const i=rows.findIndex(r=>r.handle===handle);if(i>=0)rows.splice(i,1);},cleanse(target,strength,abilityId){record('cleanse',{target,strength,abilityId});for(let i=rows.length-1;i>=0;i--)if(rows[i].target===target&&rows[i].polarity==='negative'&&rows[i].dispel!=='none'&&(strength==='strong'||rows[i].dispel==='basic'))rows.splice(i,1);}},
 control:{apply(s){record('control',s);const t=actors[s.target];if(!t.alive||t.invulnerable||t.debuffImmune&&!s.pierces)return null;const r={handle:'control:'+ ++sequence,duration:Math.min(1.5,s.duration)};controls.push({spec:s,receipt:r});return r;},release(handle){record('control-release',{handle});}},
 target:{route(s){record('route',s);const t=actors[s.target];if(!t.alive||t.invulnerable)return{accepted:false,reason:'untargetable',owner:s.owner,target:s.target,originalOwner:s.owner,reflected:false};const reflected=!!t.counter&&s.reflectable&&!s.reflected;if(reflected)t.counter=false;return{accepted:true,reason:null,owner:reflected?s.target:s.owner,target:reflected?s.owner:s.target,originalOwner:s.owner,reflected,noReflect:reflected,noLifesteal:reflected};}},
 motion(s){record('motion',s);actors[s.actor].x=Math.max(45,Math.min(1155,s.destinationX));return'motion:'+ ++sequence;},
 schedule(s){record('schedule',s);const j={...s,at:time+s.delay,handle:'job:'+ ++sequence};jobs.push(j);return j.handle;},cancelJob(handle){record('cancel-job',{handle});const i=jobs.findIndex(j=>j.handle===handle);if(i>=0)jobs.splice(i,1);},
 legacyEffect:{spawn(s){record('area',s);const z={...s,handle:'area:'+ ++sequence};areas.push(z);return z.handle;},view(handle){return areas.find(z=>z.handle===handle)??null;},end(handle,reason){record('area-end',{handle,reason});const i=areas.findIndex(z=>z.handle===handle);if(i>=0)areas.splice(i,1);}},cue(s){record('cue',s);}
 }};
 return{host,actors,requests,receipts,rows,jobs,areas,controls,setNow:v=>time=v};
}
export function deliver(session,heroId,slot,h,job=h.jobs[0]){const i=h.jobs.indexOf(job);if(i>=0)h.jobs.splice(i,1);h.setNow(job.at);return session.scheduled(heroId,slot,job.handler,h.host,{...job.data,handle:job.handle});}
