import test from 'node:test';
import assert from 'node:assert/strict';
import {createHeroRegistry, createRuleSession} from '../index.js';
import {directHitFactory, registerLegacyDirectHits} from '../rules/legacy-0-9/index.js';
import {testHost} from './host.mjs';

function run(heroId, fixture = testHost([heroId, 5], 0), registry = registerLegacyDirectHits(createHeroRegistry())) {
  const sealed = registry.seal(), session = createRuleSession(sealed), abilityId = sealed.hero(heroId).abilities[3].id;
  const result = session.invoke(heroId, 3, 'activate', fixture.host, {owner: 0, target: 1, abilityId, slot: 3, castId: 'fixture:1', direction: 1, aimX: 650, heldSeconds: 0, reflected: false});
  return {fixture, sealed, session, result};
}

test('registry retains exactly 46 heroes and the three frozen slices; adds two actual handlers', () => {
  const sealed = registerLegacyDirectHits(createHeroRegistry()).seal();
  assert.equal(sealed.definitions.length, 46);
  assert.deepEqual(sealed.manifest.map(x => [x.heroId, x.slot]), [[3,3],[5,1],[5,3],[8,3],[9,1]]);
  assert.equal(sealed.implementation(3, 0), null);
});

for (const [heroId, amount] of [[3,475], [8,760]]) {
  test('harness direct hit ' + heroId + ': finite actual debit, one host commit, no RNG', () => {
    const f = testHost([heroId, 5], 0); f.actors[1].x = 520;
    const r = run(heroId, f);
    assert.equal(f.receipts.length, 1); assert.equal(f.receipts[0].actual, amount);
    assert.equal(f.seed(), 0); assert.equal(r.session.snapshot().namespaces.length, 0);
  });
  test('harness direct hit ' + heroId + ': range edge, guard chip, invulnerability and reflection', () => {
    const m = createHeroRegistry().definition(heroId).abilities[3].mvp;
    for (const [offset, count] of [[m.range_wu+22,1],[m.range_wu+22+.0001,0]]) {const f=testHost([heroId,5]); f.actors[1].x=450+offset; run(heroId,f); assert.equal(f.receipts.length,count);}
    const guarded=testHost([heroId,5]); guarded.actors[1].x=520; guarded.actors[1].guarding=true; run(heroId,guarded); assert.equal(guarded.receipts[0].actual,amount*.2);
    const immune=testHost([heroId,5]); immune.actors[1].x=520; immune.actors[1].invulnerable=true; run(heroId,immune); assert.equal(immune.receipts[0].actual,0);
    const reflect=testHost([heroId,5]); reflect.actors[1].x=520; reflect.actors[1].counter=true; const r=run(heroId,reflect); assert.equal(reflect.receipts[0].actual,amount); assert.equal(reflect.actors[1].hp,1000); assert.deepEqual(r.result.value,{reflected:true});
  });
}

test('coefficient replacement changes actual debit/hash without changing original registry', () => {
  const r=registerLegacyDirectHits(createHeroRegistry()), a=r.definition(3).abilities[3];
  r.replaceSkill(3,3,{definition:{...a,mvp:{...a.mvp,damage:222}}},{abilityId:a.id,revision:'1.0.0'});
  const f=testHost([3,5]); f.actors[1].x=520; const next=run(3,f,r);
  assert.equal(f.receipts[0].actual,222); assert.notEqual(next.sealed.rulesHash,registerLegacyDirectHits(createHeroRegistry()).seal().rulesHash);
});

test('declared behavior parameters change real debit; cross-hash restore is atomic', () => {
  const r=registerLegacyDirectHits(createHeroRegistry()), a=r.definition(3).abilities[3];
  r.replaceSkill(3,3,{definition:a,factory:directHitFactory({damageMultiplier:.5,bodyPadding:22})},{abilityId:a.id,revision:'1.0.0'});
  const f=testHost([3,5]); f.actors[1].x=520; const next=run(3,f,r);
  assert.equal(f.receipts[0].actual,237.5);
  const other=createRuleSession(registerLegacyDirectHits(createHeroRegistry()).seal()), before=next.session.snapshot();
  assert.throws(()=>next.session.restore(other.snapshot()),/Incompatible/); assert.deepEqual(next.session.snapshot(),before);
});

test('consumed and unsupported dependent coefficients reject atomically before payment', () => {
  for (const delta of [{damage:-1},{damage:'1'},{damage:0,damage_type:'none'},{stun_s:61},{slow_pct:1},{root_s:1},{knockback_wu:1},{hitstun_s:61}]) {
    const r=registerLegacyDirectHits(createHeroRegistry()), before=r.definition(3), a=before.abilities[3];
    assert.throws(()=>r.replaceSkill(3,3,{definition:{...a,mvp:{...a.mvp,...delta}}},{abilityId:a.id,revision:'1.0.0'})); assert.equal(r.definition(3),before);
  }
  for (const parameters of [{damageMultiplier:Infinity,bodyPadding:22},{damageMultiplier:-1,bodyPadding:22},{damageMultiplier:1e7,bodyPadding:22},{damageMultiplier:1,bodyPadding:101},{damageMultiplier:1,bodyPadding:22,secret:0}]) assert.throws(()=>registerLegacyDirectHits(createHeroRegistry(),parameters));
});
