// PUBLIC-ONLY RECORDER. No private runtime and no HP/MP/physics simulation.
export function recorder(heroIds=[3,5],seed=0) {
  const actors=heroIds.map((heroId,id)=>({id,heroId,hp:1000,maxHp:1000,mp:500,maxMp:1200,x:id?650:530,y:0,dir:id?-1:1,alive:true,invulnerable:false,debuffImmune:false,passivesEnabled:true,guarding:false,rooted:false,silenced:false}));
  const requests=[],queryFacts=new Map();let reflect=false,routeAccepted=true,controlAccepted=true,damageAccepted=true;
  const receipt=()=>({accepted:damageAccepted,landed:damageAccepted,guarded:false,raw:0,actual:0,deferred:0,killedAtDebit:false});
  const record=(port,request)=>requests.push({port,request:structuredClone(request)});
  const host={now:()=>0,actor:id=>actors[id],random:()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;},ports:{
    status:{apply(spec){record('status.apply',spec);return 'recorded-status:'+requests.length;},query(target,key){return queryFacts.get(target+':'+key)??[];},remove(handle){record('status.remove',handle);return true;},cleanse(){throw Error('No draft may cleanse here');}},
    control:{apply(spec){record('control.apply',spec);return controlAccepted?{handle:'recorded-control',duration:Math.min(1.5,spec.duration)}:null;},release(){throw Error('No draft may release here');}},
    motion(spec){record('motion',spec);return 'recorded-motion';},
    damage(spec){record('damage',spec);return {...receipt(),raw:spec.amount};},
    target:{route(spec){record('target.route',spec);return {accepted:routeAccepted,reason:routeAccepted?null:'recorded-rejection',owner:reflect?spec.target:spec.owner,target:reflect?spec.owner:spec.target,originalOwner:spec.owner,reflected:reflect,noReflect:reflect,noLifesteal:reflect};}},
    cue(spec){record('cue',spec);}
  }};
  return {host,actors,requests,queryFacts,seed:()=>seed,setReflection:value=>{reflect=value;},rejectRoute:()=>{routeAccepted=false;},rejectControl:()=>{controlAccepted=false;},rejectDamage:()=>{damageAccepted=false;}};
}
