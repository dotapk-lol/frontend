import test from 'node:test';
import assert from 'node:assert/strict';
import {createHeroRegistry,createRuleSession} from '../index.js';
import {registerLegacyPassiveProjections} from '../rules/legacy-0-9/index.js';
import {testHost} from './host.mjs';
const build=()=>registerLegacyPassiveProjections(createHeroRegistry());
function project(hero,slot,hook,event,f=testHost([hero,3],0),r=build()) {const session=createRuleSession(r.seal());return {value:session.invoke(hero,slot,hook,f.host,event).value,fixture:f,session};}

test('five real projection hooks register without activate fallbacks or extra ports',()=>{
  const r=build().seal();assert.equal(r.manifest.length,8);
  for(const [hero,slot,hook] of [[0,2,'projectAttack'],[1,2,'projectInterval'],[4,1,'projectAttack'],[6,2,'projectDamage'],[7,3,'projectAttack']]) {assert.equal(typeof r.implementation(hero,slot)[hook],'function');assert.equal(r.implementation(hero,slot).activate,undefined);assert.deepEqual(r.implementation(hero,slot).requires,[]);}
});
test('headshot finite guarantee fact preserves RNG short circuit and declared modifiers',()=>{
  const f=testHost([4,3],0),g=testHost([4,3],0);
  const value=project(4,1,'projectAttack',{owner:0,guaranteed:false},f).value;
  assert.deepEqual(value,{proc:true,damageBonus:110,knockbackBonus:27.500000000000004,slowPercentage:100,slowSeconds:.5});assert.equal(f.seed(),1013904223);
  assert.deepEqual(project(4,1,'projectAttack',{owner:0,guaranteed:true},g).value,value);assert.equal(g.seed(),0);
  g.actors[0].passivesEnabled=false;assert.equal(project(4,1,'projectAttack',{owner:0,guaranteed:true},g).value.proc,false);assert.equal(g.seed(),0);
});
test('seed 0 is consumed exactly once for eligible crit/evasion/marksmanship, never for broken/near/non-basic',()=>{
  for(const [hero,slot,hook,event] of [[0,2,'projectAttack',{owner:0,damage:100}],[6,2,'projectDamage',{owner:0,basic:true}],[7,3,'projectAttack',{owner:0,target:1,damage:100}]]) {
    const f=testHost([hero,3],0);project(hero,slot,hook,event,f);assert.equal(f.seed(),1013904223);
    const b=testHost([hero,3],0);b.actors[0].passivesEnabled=false;project(hero,slot,hook,event,b);assert.equal(b.seed(),0);
  }
  const f=testHost([7,3],0);f.actors[1].x=500;project(7,3,'projectAttack',{owner:0,target:1,damage:100},f);assert.equal(f.seed(),0);
  const g=testHost([6,3],0);project(6,2,'projectDamage',{owner:0,basic:false},g);assert.equal(g.seed(),0);
});
test('default projections produce real declared values from frozen coefficients',()=>{
  assert.deepEqual(project(0,2,'projectAttack',{owner:0,damage:100}).value,{damage:200});
  assert.deepEqual(project(6,2,'projectDamage',{owner:0,basic:true}).value,{evaded:true});
  assert.deepEqual(project(7,3,'projectAttack',{owner:0,target:1,damage:100}).value,{damage:190});
  const h=build().definition(1),m=h.abilities[2].mvp;
  assert.deepEqual(project(1,2,'projectInterval',{owner:0,kind:'mana-regeneration'}).value,{manaPerSecond:(h.mana_regen+m.manaRegenBonus)*(1+m.manaRegenAmp)});
});
test('definition replacement rederives captured coefficients and changes returned behavior/hash',()=>{
  for(const [hero,slot,hook,event,delta,expected] of [[0,2,'projectAttack',{owner:0,damage:100},{critChance:1,critMultiplier:3},{damage:300}],[6,2,'projectDamage',{owner:0,basic:true},{evasion:0},{evaded:false}],[7,3,'projectAttack',{owner:0,target:1,damage:100},{procChance:1,attack_bonus:17},{damage:117}]]) {
    const r=build(),a=r.definition(hero).abilities[slot];r.replaceSkill(hero,slot,{definition:{...a,mvp:{...a.mvp,...delta}}},{abilityId:a.id,revision:'1.0.0'});const next=project(hero,slot,hook,event,testHost([hero,3],0),r);assert.deepEqual(next.value,expected);assert.notEqual(next.session.sealed.rulesHash,build().seal().rulesHash);
  }
});
test('finite projection events cannot contain Engine/actor objects or mutate HP',()=>{
  const f=testHost([0,3],0),before=structuredClone(f.actors);
  assert.throws(()=>project(0,2,'projectAttack',{owner:0,damage:100,engine:{}},f),/finite projection event/);
  assert.throws(()=>project(0,2,'projectAttack',{owner:0,damage:-1},f),/Invalid/);
  assert.deepEqual(f.actors,before);assert.equal(f.seed(),0);
  const r=project(0,2,'projectAttack',{owner:0,damage:100},f);assert.deepEqual(f.actors,before);assert.deepEqual(r.session.snapshot().namespaces,[]);
});
test('bounded consumed passive coefficients reject atomically',()=>{
  for(const [hero,slot,delta] of [[0,2,{critMultiplier:101}],[7,3,{procChance:2}],[1,2,{manaRegenAmp:Infinity}],[1,2,{manaRegenBonus:-1}],[6,2,{evasion:2}]]) {
    const r=build(),before=r.definition(hero),a=before.abilities[slot];assert.throws(()=>r.replaceSkill(hero,slot,{definition:{...a,mvp:{...a.mvp,...delta}}},{abilityId:a.id,revision:'1.0.0'}));assert.equal(r.definition(hero),before);
  }
});
