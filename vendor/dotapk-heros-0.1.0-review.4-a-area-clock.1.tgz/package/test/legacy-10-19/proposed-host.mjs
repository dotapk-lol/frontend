// Controlled detached command harness only. No native Engine, physics, input,
// AI, action loop, native timing parity, or browser acceptance is implied.
export function proposedHost(heroId=12){
 const actors=[0,1].map(id=>({id,heroId:id?3:heroId,hp:1000,maxHp:1000,mp:1200,maxMp:1200,x:id?650:530,y:0,dir:id?-1:1,alive:true,invulnerable:false,debuffImmune:false,passivesEnabled:true,guarding:false,rooted:false,silenced:false}));
 let sequence=0;const records=[],requests=[],trace=[];
 function apply(s){requests.push({port:'status.apply',spec:structuredClone(s)});const old=records.findIndex(r=>r.target===s.target&&r.key===s.key);if(old>=0)records.splice(old,1);const r={...structuredClone(s),handle:'harness:status:'+sequence++,remainingSeconds:s.duration,effective:true,...(s.values.initialRevealSeconds!==undefined?{revealSeconds:s.values.initialRevealSeconds}:{})};records.push(r);return r.handle;}
 const host={now:()=>0,random:()=>{throw Error('Unexpected random draw');},actor:id=>actors[id],ports:{
  status:{apply,query:(target,key)=>records.filter(r=>r.target===target&&r.key===key),remove(handle){requests.push({port:'status.remove',handle});const i=records.findIndex(r=>r.handle===handle);if(i<0)return false;records.splice(i,1);return true;}},
  damage(s){requests.push({port:'damage',spec:structuredClone(s)});trace.push('damage-begin');const t=actors[s.target],accepted=t.alive&&!t.invulnerable,guarded=t.guarding&&s.blockable!==false;const before=t.hp,amount=accepted?(guarded?Math.min(s.amount*.2,Math.max(0,before-1)):s.amount):0;t.hp=Math.max(0,before-amount);t.alive=t.hp>0;
   // Proposed descriptor stage simulation: accepted unguarded legacy hit applies
   // weak even with debuff immunity or a lethal debit. This is NOT native proof.
   if(s.onLandedLegacyStatus&&accepted&&!guarded){trace.push('weak-commit');apply(s.onLandedLegacyStatus);}trace.push('damage-end');return {accepted,landed:accepted&&!guarded,guarded,raw:s.amount,actual:before-t.hp,deferred:0,killedAtDebit:before>0&&!t.alive};}
 }};
 return {host,actors,records,requests,trace,applyReveal(result){for(const update of result.legacyRevealUpdates??[]){const r=records.find(r=>r.handle===update.handle);if(!r)throw Error('Stale harness reveal update');r.revealSeconds=update.revealSeconds;}}};
}
