// Resource transactions + fixed geometry only. No simulation loop, physics, AI,
// input, match, networking or production Engine, including no hidden copy.
export function testHost(heroIds=[5,3],seed=8192){
 const actors=heroIds.map((heroId,id)=>({id,heroId,hp:1000,maxHp:1000,mp:200,maxMp:1200,x:id?650:450,y:0,dir:id?-1:1,alive:true,invulnerable:false,debuffImmune:false,passivesEnabled:true,guarding:false,rooted:false,silenced:false})),receipts=[],requests=[],controls=[];
 const host={now:()=>0,actor:id=>actors[id],random:()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;},ports:{
  damage(spec){requests.push(spec);const t=actors[spec.target],accepted=t.alive&&!t.invulnerable,guarded=t.guarding&&spec.blockable!==false&&!spec.dot;const raw=spec.amount,amount=accepted?(guarded?Math.min(raw*.2,Math.max(0,t.hp-1)):raw):0,before=t.hp;t.hp=Math.max(0,t.hp-amount);t.alive=t.hp>0;const receipt={accepted,landed:accepted&&!guarded,guarded,raw,actual:before-t.hp,deferred:0,killedAtDebit:before>0&&!t.alive};receipts.push(receipt);return receipt;},
  heal(spec){requests.push(spec);const t=actors[spec.target],actual=t.alive?Math.min(spec.amount,t.maxHp-t.hp):0;t.hp+=actual;return {actual,deferred:0};},
  control:{apply(spec){requests.push(spec);const t=actors[spec.target];if(!t.alive||t.invulnerable||t.debuffImmune&&!spec.pierces)return null;const receipt={handle:'control:'+controls.length,duration:Math.min(1.5,spec.duration)};controls.push({spec,receipt});return receipt;}},
  motion(spec){requests.push(spec);actors[spec.actor].x=Math.max(45,Math.min(1155,spec.destinationX));return 'motion:0';},
  protect(spec){requests.push(spec);actors[spec.actor].invulnerable=spec.duration>0;return 'protect:0';},
  target:{route(spec){const reflected=!!actors[spec.target].counter&&!spec.reflected;return {accepted:true,reason:null,owner:reflected?spec.target:spec.owner,target:reflected?spec.owner:spec.target,originalOwner:spec.owner,reflected,noReflect:reflected,noLifesteal:reflected};}},
  cue(spec){requests.push(spec);}
 }};
 return {host,actors,receipts,requests,controls,seed:()=>seed};
}
