import {createHeroRegistry} from '../../index.js';import {registerC} from '../../rules/c/index.js';import {createHost} from './host.mjs';
export function sample(id,slot,side=0,registry=registerC(createHeroRegistry())){const x=createHost(side?[0,id]:[id,0],registry),f=x.actors[side],t=x.actors[1-side];f.x=side?600:400;t.x=500;
 if(id===106&&slot===3)f.x=side?1055:100;
 if(id===117&&slot===1)t.x=f.x+(side?-1:1)*286;
 if(id===94&&slot===3)t.x=f.x+(side?-1:1)*30;
 if(id===121&&[2,3].includes(slot))f.hp=4500;
 const a=x.sealed.hero(id).abilities[slot];
 let c;if(id===124&&slot===2){c={plan:{accepted:true}};x.invoke(id,slot,'onAttack',{owner:side,attacker:side,target:1-side,landed:true,attackId:10,attackBonus:0});}
 else {c=x.cast(side,slot);if(a.mvp.passive){if(id===94)x.invoke(id,slot,'onAttack',{owner:side,attacker:1-side,target:side,landed:true});if(id===106)x.projection=x.invoke(id,slot,'projectAttack',{owner:side,attacker:1-side,target:side,amount:100});if(id===121)for(let i=0;i<4;i++)x.invoke(id,slot,'onAttack',{owner:side,attacker:side,target:1-side,landed:true,attackId:i,receipt:{attackId:i,actual:200}});}}
 for(const h of [...x.jobs.keys()])x.deliver(h);
 for(const [h,row] of x.effects)if(row.alive)x.stage(side,slot,{kind:'field',handle:h,ageSeconds:id===124&&slot===1?0:.5,pulses:1,nextEligibleTime:0});
 for(const h of [...x.projectiles.keys()])x.contact(h);
 for(const h of [...x.status.keys()])x.deliverStatus(h);
 if(id===94&&slot===3)x.stage(side,slot,{kind:'contact-check'});
 if(id===104&&slot===2)x.damage({source:1-side,target:side,abilityId:'harness_incoming',amount:1000,type:'magical',blockable:false});
 if(id===124&&slot===3){x.projection=x.invoke(id,slot,'projectAttack',{owner:side,attacker:side,target:1-side,amount:100});x.damage({source:side,target:1-side,abilityId:'harness_attack',amount:x.projection.amount,type:x.projection.type,blockable:false});}
 return {x,c,a};
}
