import test from 'node:test';import assert from 'node:assert/strict';
import {createHeroRegistry,createRuleSession,heroes} from '../index.js';
import {registerLegacy0To9} from '../rules/legacy-0-9/index.js';
import {registerLegacyNextDrafts,legacyActiveDraftFactory} from '../rules/legacy-0-9/next/index.js';
import {recorder} from './legacy-next-recorder.mjs';
const selected=[[2,2],[3,0],[4,2],[5,2],[6,1],[8,1],[9,3]],build=()=>registerLegacyNextDrafts(registerLegacy0To9(createHeroRegistry()));
function run(id,slot,fixture=recorder([id,5]),registry=build(),extra={}) {
  const sealed=registry.seal(),session=createRuleSession(sealed),abilityId=sealed.hero(id).abilities[slot].id;
  const event={owner:0,target:1,abilityId,slot,castId:'recorder:1',direction:1,aimX:650,heldSeconds:0,reflected:false,...extra};
  const result=session.invoke(id,slot,'activate',fixture.host,event);return {sealed,session,fixture,result};
}
const requests=(fixture,port)=>fixture.requests.filter(x=>x.port===port).map(x=>x.request);

test('seven draft factories actually register; roster and frozen first-seven identities stay unchanged',()=>{
  const before=registerLegacy0To9(createHeroRegistry()).seal(),next=build().seal();
  assert.equal(next.definitions.length,46);assert.equal(next.manifest.length,17);assert.deepEqual(next.definitions,before.definitions);
  for(const row of before.manifest)assert.deepEqual(next.manifest.find(x=>x.heroId===row.heroId&&x.slot===row.slot),row);
  for(const [id,slot]of selected)assert.equal(typeof next.implementation(id,slot).activate,'function');
  assert.equal(next.implementation(7,0),null);assert.equal(heroes.length,46);
});

for(const [id,slot]of selected)test('public-only recorder '+id+'/'+slot+': finite requests without actor mutation, RNG or state',()=>{
  const f=recorder([id,5]);f.actors[1].x=600;const before=structuredClone(f.actors),r=run(id,slot,f);
  assert(f.requests.length>0);assert.deepEqual(f.actors,before);assert.equal(f.seed(),0);assert.deepEqual(r.session.snapshot().namespaces,[]);
  for(const row of f.requests)if(row.request&&typeof row.request==='object')assert.equal(row.request.abilityId,r.sealed.hero(id).abilities[slot].id);
});

test('closed status grants include only owned values, not full private recipes',()=>{
  for(const [id,slot,key,values,duration]of [[2,2,'pudge_meat_shield',{block_flat:26,block_fraction_cap:1},7],[4,2,'sniper_take_aim',{attack_range_bonus:165,self_slow:.65,headshotGuaranteed:true},3],[5,2,'counter',{mode:'spell'},1.3]]) {
    const {fixture}=run(id,slot);assert.deepEqual(requests(fixture,'status.apply'),[{owner:0,target:0,abilityId:createHeroRegistry().definition(id).abilities[slot].id,key,duration,polarity:'positive',dispel:'none',pierces:false,values}]);
    assert.deepEqual(requests(fixture,'cue')[0].kind,'cast');
  }
});

test('Meat Shield projection preserves pure exception and fraction fallback without committing damage',()=>{
  const r=build().seal(),session=createRuleSession(r),f=recorder([2,5]);
  const status={owner:0,target:0,abilityId:'pudge_meat_shield',key:'pudge_meat_shield',duration:7,polarity:'positive',dispel:'none',pierces:false,values:{block_flat:26,block_fraction_cap:1}};
  f.queryFacts.set('0:pudge_meat_shield',[status]);
  for(const type of ['pure','magical','physical'])assert.deepEqual(session.invoke(2,2,'projectDamage',f.host,{owner:0,type,damage:50}).value,{damage:24});
  status.values.block_fraction_cap=0;assert.deepEqual(session.invoke(2,2,'projectDamage',f.host,{owner:0,type:'pure',damage:50}).value,{damage:30});
  assert.equal(requests(f,'damage').length,0);
  f.queryFacts.set('0:pudge_meat_shield',[status,status]);assert.throws(()=>session.invoke(2,2,'projectDamage',f.host,{owner:0,type:'pure',damage:50}),/one replacement/);
});

test('Counterspell resistance is always-on, max-merged and break-aware, with no active-status requirement',()=>{
  const sealed=build().seal(),session=createRuleSession(sealed),f=recorder([5,3]);
  for(const [type,existing,expected]of [['magical',.2,.35],['magical',.8,.8],['pure',.2,.2],['physical',.2,.2]])assert.deepEqual(session.invoke(5,2,'projectDamage',f.host,{owner:0,type,magicReduction:existing}).value,{magicReduction:expected});
  f.actors[0].passivesEnabled=false;assert.deepEqual(session.invoke(5,2,'projectDamage',f.host,{owner:0,type:'magical',magicReduction:.2}).value,{magicReduction:.2});assert.equal(f.requests.length,0);
});

test('Axe Call skips guarded/far targets, but grants armor after a rejected control request',()=>{
  const f=recorder([3,5]);f.rejectControl();run(3,0,f);assert.deepEqual(f.requests.map(x=>x.port),['control.apply','status.apply']);assert.equal(requests(f,'control.apply')[0].duration,3);assert.equal(requests(f,'status.apply')[0].duration,3);
  for(const kind of ['guard','far']){const g=recorder([3,5]);if(kind==='guard')g.actors[1].guarding=true;else g.actors[1].x=1000;run(3,0,g);assert.equal(g.requests.length,0);}
});

test('Phantom Strike orders route, motion, real zero-damage request, speed status; rejected hit still grants speed',()=>{
  const f=recorder([6,5]);f.rejectDamage();const before=structuredClone(f.actors);run(6,1,f);
  assert.deepEqual(f.requests.map(x=>x.port),['target.route','motion','damage','status.apply']);
  assert.equal(requests(f,'motion')[0].destinationX,580);assert.equal(requests(f,'damage')[0].amount,0);assert.equal(requests(f,'damage')[0].hitstunSeconds,.12);assert.equal(requests(f,'status.apply')[0].values.attack_interval_multiplier,1/3);assert.deepEqual(f.actors,before);
});

test('Phantom Strike reflection returns before motion/status; targeted reflection flag is independent of recipe projectile flag',()=>{
  const f=recorder([6,5]);f.setReflection(true);const r=run(6,1,f);
  assert.deepEqual(f.requests.map(x=>x.port),['target.route','damage','cue']);assert.equal(requests(f,'target.route')[0].reflectable,true);assert.equal(requests(f,'damage')[0].source,1);assert.equal(requests(f,'damage')[0].reflected,true);assert.deepEqual(r.result.value,{reflected:true});
});

test('Lina Array uses committed aim and ground cutoff; ground cue is still requested after a miss',()=>{
  const f=recorder([8,5]);f.actors[1].x=800;run(8,1,f,build(),{aimX:800});assert.equal(requests(f,'damage')[0].amount,215);assert.equal(requests(f,'damage')[0].stunSeconds,2.4);assert.equal(requests(f,'cue')[0].kind,'hit');assert.equal(requests(f,'target.route').length,0);
  for(const [x,y]of [[1000,0],[650,45]]){const g=recorder([8,5]);g.actors[1].x=x;g.actors[1].y=y;run(8,1,g);assert.equal(requests(g,'damage').length,0);assert.equal(requests(g,'cue').length,1);}
});

test('Lion Finger grants form before normal hit, grants it out of range, and never grants it on reflection',()=>{
  const f=recorder([9,5]);run(9,3,f);assert.deepEqual(f.requests.map(x=>x.port),['target.route','status.apply','damage','cue']);assert.deepEqual(requests(f,'status.apply')[0].values,{attack_range_override:137.5,attack_bonus:40,move_bonus:16.5,melee:true});assert.equal(requests(f,'damage')[0].amount,850);
  const far=recorder([9,5]);far.actors[1].x=1155;run(9,3,far);assert.deepEqual(far.requests.map(x=>x.port),['status.apply']);
  const reflect=recorder([9,5]);reflect.setReflection(true);const r=run(9,3,reflect);assert.deepEqual(reflect.requests.map(x=>x.port),['target.route','damage','cue']);assert.deepEqual(r.result.value,{reflected:true});
});

test('out-of-range/rejected routes do not manufacture movement or damage',()=>{
  for(const id of [6,9]){const slot=id===6?1:3,f=recorder([id,5]);f.rejectRoute();run(id,slot,f);assert.deepEqual(f.requests.map(x=>x.port),['target.route']);}
});

test('draft coefficient/parameter replacement changes declared effects and rules hash, not claimed private outcomes',()=>{
  const r=build(),a=r.definition(4).abilities[2];r.replaceSkill(4,2,{definition:{...a,mvp:{...a.mvp,attack_range_bonus:200}}},{abilityId:a.id,revision:'0.1.0'});const changed=run(4,2,recorder([4,5]),r);assert.equal(requests(changed.fixture,'status.apply')[0].values.attack_range_bonus,200);assert.notEqual(changed.sealed.rulesHash,build().seal().rulesHash);
  const p=build(),finger=p.definition(9).abilities[3];p.replaceSkill(9,3,{definition:finger,factory:legacyActiveDraftFactory('lion_finger',{bodyPadding:22,groundCutoff:45,worldScale:.6})},{abilityId:finger.id,revision:'0.1.0'});const scale=run(9,3,recorder([9,5]),p);assert.equal(requests(scale.fixture,'status.apply')[0].values.attack_range_override,150);assert.equal(requests(scale.fixture,'status.apply')[0].values.move_bonus,18);assert.notEqual(scale.sealed.rulesHash,changed.sealed.rulesHash);assert.throws(()=>scale.session.restore(changed.session.snapshot()),/Incompatible/);
});

test('unsupported added modifiers, invalid consumed coefficients and effect families reject before invocation',()=>{
  for(const[id,slot,delta]of [[2,2,{block_fraction_cap:2}],[2,2,{block_flat:'26'}],[4,2,{self_slow:2}],[4,2,{headshotGuaranteed:1}],[5,2,{officialSemantic:{passive_magic_resistance_pct:101}}],[3,0,{physical_reduction:-1}],[6,1,{buff_duration_s:61}],[8,1,{damage:0,damage_type:'none'}],[8,1,{slow_pct:20}],[9,3,{root_s:1}],[4,2,{cleanse:['root']}],[2,2,{toggle:true}]]) {
    const r=build(),before=r.definition(id),a=before.abilities[slot];assert.throws(()=>r.replaceSkill(id,slot,{definition:{...a,mvp:{...a.mvp,...delta}}},{abilityId:a.id,revision:'0.1.0'}));assert.equal(r.definition(id),before);
  }
});

test('extra opaque Engine/actor event fields reject, and missing host status remains a visible blocker',()=>{
  const f=recorder([4,5]),before=structuredClone(f.actors);assert.throws(()=>run(4,2,f,build(),{engine:{}}),/closed draft cast/);assert.equal(f.requests.length,0);assert.deepEqual(f.actors,before);
  const missing=recorder([4,5]);delete missing.host.ports.status;assert.throws(()=>run(4,2,missing),/Missing declared port: status.apply/);assert.equal(missing.requests.length,0);
});
test('missing cue after recorded status demonstrates the explicit preflight gate, not private atomicity',()=>{
  const f=recorder([4,5]);delete f.host.ports.cue;
  assert.throws(()=>run(4,2,f),/Missing declared port: cue/);
  assert.deepEqual(f.requests.map(x=>x.port),['status.apply']);
});
test('invalid execution parameters reject replacement atomically at registry compile',()=>{
  for(const parameters of [{bodyPadding:-1,groundCutoff:45,worldScale:.55},{bodyPadding:22,groundCutoff:Infinity,worldScale:.55},{bodyPadding:22,groundCutoff:45,worldScale:2},{bodyPadding:22,groundCutoff:45,worldScale:.55,opaque:{}}]) {
    const r=build(),before=r.definition(9),a=before.abilities[3];assert.throws(()=>r.replaceSkill(9,3,{definition:a,factory:legacyActiveDraftFactory('lion_finger',parameters)},{abilityId:a.id,revision:'0.1.0'}));assert.equal(r.definition(9),before);assert.equal(r.seal().rulesHash,build().seal().rulesHash);
  }
});
