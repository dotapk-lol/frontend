import test from 'node:test';
import assert from 'node:assert/strict';
import {heroes,createHeroRegistry,createRuleSession} from '../index.js';
import {registerA,A_HERO_IDS} from '../rules/a/register.js';
import {aHost} from './a-host.mjs';

test('contract.3 all A harness actors start at their actual sealed production MP ceiling',()=>{
 const sealed=registerA(createHeroRegistry()).seal(),session=createRuleSession(sealed);
 const expected={21:687,28:609,29:658,32:1105,36:902,42:975,47:638,50:1053,55:719};
 for(const id of A_HERO_IDS){
  const f=aHost(id,3,sealed.definitions);
  assert.equal(session.validateFacts(f.host),true);
  for(const actor of f.actors){
   const ceiling=sealed.resources.maxMpByHero[actor.heroId];
   assert.equal(actor.maxMp,ceiling);assert.equal(actor.mp,ceiling);
   assert.equal(ceiling,sealed.hero(actor.heroId).combatMana);
  }
  assert.equal(f.actors[0].maxMp,expected[id]);
 }
});

test('contract.3 deliberately illegal negative probes still reject before any A effects or state writes',()=>{
 const sealed=registerA(createHeroRegistry()).seal(),a=sealed.hero(50).abilities[2];
 // These are rejection probes, never admissible initial match fixtures.
 for(const change of [{maxMp:1200},{mp:1054},{mp:-1},{maxMp:0,mp:0}]){
  const session=createRuleSession(sealed),f=aHost(50,3,sealed.definitions);
  Object.assign(f.actors[0],change);
  const actors=structuredClone(f.actors),state=session.snapshot();
  assert.equal(session.validateFacts(f.host),false);
  for(const hook of ['planCast','activate'])assert.throws(()=>session.invoke(50,2,hook,f.host,{
   owner:0,target:1,abilityId:a.id,slot:2,castId:'harness:invalid-mp',direction:1,
   aimX:650,actionReady:true,manaAvailable:f.actors[0].mp,cooldownRemaining:0,chargesAvailable:0
  }),/Actor mana exceeds declared resource schema/);
  assert.deepEqual(f.actors,actors);assert.deepEqual(session.snapshot(),state);
  assert.equal(f.requests.length,0);assert.equal(f.receipts.length,0);assert.equal(f.jobs.size,0);
 }
});

test('contract.3 A helper follows the supplied sealed resource schema without enlarging production ceilings',()=>{
 const definitions=structuredClone(heroes);
 definitions.find(h=>h.registryNumericId===50).combatMana=500;
 const changed=registerA(createHeroRegistry(definitions)).seal(),session=createRuleSession(changed);
 const f=aHost(50,3,changed.definitions);
 assert.equal(f.actors[0].maxMp,500);assert.equal(f.actors[0].mp,500);
 assert.equal(session.validateFacts(f.host),true);
 assert.equal(createHeroRegistry().seal().resources.maxMpByHero[50],1053);
 assert.equal(aHost(50).actors[0].maxMp,1053);
});
