// Controlled command harness only: returns facts, records existing target-route,
// consumes seeded RNG; never submits a command, mutates HP/MP or advances time.
import {createHeroRegistry,createRuleSession} from '../index.js';
import {registerAllLegacy0To9} from '../rules/legacy-0-9/all-owned.js';
import {EVENT_VERSION,FEATURES} from '../rules/legacy-0-9/remaining.js';
export const enabled={hostSemantics:EVENT_VERSION,hostCapabilities:FEATURES};
export const sealed=registerAllLegacy0To9(createHeroRegistry(),enabled).seal();
export function fixture(hero,slot,seed=0,registry=sealed){
 const actors=[hero,hero].map((heroId,id)=>({id,heroId,hp:1000,maxHp:1000,mp:200,maxMp:registry.hero(heroId).combatMana??registry.hero(heroId).mana??1200,x:id?600:500,y:0,dir:id?-1:1,alive:true,invulnerable:false,debuffImmune:false,passivesEnabled:true,guarding:false,rooted:false,silenced:false}));
 let draws=0,reflect=false;const requests=[];
 const host={now:()=>0,actor:id=>actors[id],random:()=>{draws++;seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;},ports:{target:{route(spec){requests.push(structuredClone(spec));return {accepted:true,reason:null,owner:reflect?spec.target:spec.owner,target:reflect?spec.owner:spec.target,originalOwner:spec.owner,reflected:reflect,noReflect:reflect,noLifesteal:reflect};}}}};
 const session=createRuleSession(registry),base={owner:0,target:1,abilityId:registry.hero(hero).abilities[slot].id,slot,castId:'cast:1',legacySemantics:EVENT_VERSION,legacyCapabilities:FEATURES};
 return {actors,host,session,requests,base,draws:()=>draws,seed:()=>seed,setReflection:v=>{reflect=v;},invoke(hook,data={},owner=0){return session.invoke(hero,slot,hook,host,{...base,owner,target:1-owner,...data}).value;}};
}
