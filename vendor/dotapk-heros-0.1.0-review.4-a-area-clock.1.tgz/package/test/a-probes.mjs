import {BATTLE_ABI,codeIdentity,EMPTY_STATE_SCHEMA} from '../index.js';
export function replacementFactory(amount){return {abiVersion:BATTLE_ABI,parameters:{amount},create({definition,parameters}){
 if(!parameters||Object.keys(parameters).join(',')!=='amount'||!Number.isFinite(parameters.amount)||parameters.amount<0||parameters.amount>1e7)throw Error('Invalid replacement parameters');
 return {behaviorId:'harness/a-replacement/'+definition.id,revision:'3.0.0',...codeIdentity(['test/a-probes.mjs']),requires:['heal'],stateSchema:EMPTY_STATE_SCHEMA,
  activate(ctx,c){try{ctx.actor(c.owner).hp=0;throw Error('Writable actor');}catch(e){if(!(e instanceof TypeError))throw e;}if(ctx.engine!==undefined||ctx.input!==undefined)throw Error('Private host access');return ctx.heal({source:c.owner,target:c.owner,abilityId:definition.id,amount:parameters.amount});}
 };
}};}
