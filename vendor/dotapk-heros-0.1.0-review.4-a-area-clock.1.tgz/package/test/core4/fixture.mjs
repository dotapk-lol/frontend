import {createHeroRegistry,createRuleSession} from '../../index.js';
import {registerCore4} from '../../rules/core4/index.js';
import {testHost} from '../host.mjs';
export function setup(heroId,slot,{side=0,params=null}={}){
 const registry=registerCore4(createHeroRegistry()),original=registry.definition(heroId).abilities[slot];
 if(params)registry.replaceSkill(heroId,slot,{definition:{...original,mvp:{...original.mvp,params:{...original.mvp.params,...params}}}},{abilityId:original.id,revision:'1.0.0'});
 const sealed=registry.seal(),session=createRuleSession(sealed),t=testHost(side?[3,heroId]:[heroId,3]),records=[],effects=[],missiles=[],statuses=[];let seq=0,now=0;
 for(const f of t.actors){f.maxHp=10000;f.hp=10000;f.mp=1200;}
 const request=spec=>{records.push(structuredClone(spec));return spec;};
 const ports=t.host.ports;
 ports.mana=spec=>{request(spec);const f=t.actors[spec.actor],before=f.mp;f.mp=Math.max(0,Math.min(f.maxMp,f.mp+spec.delta));return f.mp-before;};
 ports.selfDamage=spec=>{request(spec);const f=t.actors[spec.actor],before=f.hp;f.hp=Math.max(spec.nonlethal?1:0,f.hp-spec.amount);return {accepted:true,landed:true,guarded:false,raw:spec.amount,actual:before-f.hp,deferred:0,killedAtDebit:before>0&&f.hp===0};};
 ports.status={apply(spec){request(spec);const f=t.actors[spec.target];if(!f.alive||spec.polarity==='negative'&&(f.invulnerable||f.debuffImmune&&!spec.pierces))return null;const h='status:'+seq++;statuses.push({...structuredClone(spec),handle:h,elapsed:0,remaining:spec.duration});return h;},query(target,key){return statuses.filter(s=>s.target===target&&s.key===key&&s.remaining>1e-8);},remove(h){const i=statuses.findIndex(s=>s.handle===h);if(i<0)return false;statuses.splice(i,1);return true;},cleanse(target,tier,id){request({target,tier,abilityId:id});const removed=statuses.filter(s=>s.target===target&&(s.dispel==='basic'||tier==='strong'&&s.dispel==='strong'));for(const s of removed)ports.status.remove(s.handle);return removed.map(s=>s.handle);}};
 ports.legacyEffect={spawn(spec){request(spec);const h='effect:'+seq++;effects.push({handle:h,...structuredClone(spec)});return h;},view(h){const f=effects.find(e=>e.handle===h);return f?{alive:true,x:f.x,y:0}:null;},end(h){const i=effects.findIndex(e=>e.handle===h);if(i<0)return false;effects.splice(i,1);return true;}};
 ports.projectile=spec=>{request(spec);const h='missile:'+seq++;missiles.push({handle:h,...structuredClone(spec)});return h;};
 const host={...t.host,now:()=>now};
 const abilityId=sealed.hero(heroId).abilities[slot].id;
 const invoke=(hook,event={})=>session.invoke(heroId,slot,hook,host,{abilityId,...event}).value;
 const cast=(event={})=>invoke('activate',{owner:side,target:1-side,castId:'cast:0',aimX:t.actors[1-side].x,direction:side?-1:1,heldSeconds:0,reflected:false,...event});
 return {...t,host,ports,registry,sealed,session,records,effects,missiles,statuses,invoke,cast,side,target:1-side,abilityId,advance(dt){now+=dt;for(const s of statuses){s.elapsed+=Math.min(dt,s.remaining);s.remaining=Math.max(0,s.remaining-dt);}},plan(event={}){return invoke('planCast',{owner:side,target:1-side,actionReady:true,manaAvailable:t.actors[side].mp,cooldownRemaining:0,chargesAvailable:0,...event});}};
}
