# @dotapk/heros — local review candidate

Pure deterministic rule factories and numeric catalog for a 2D Dota hero duel adaptation. This private review package uses ABI `heros-effects-2`, ES modules and Node 22+. It contains no renderer, match loop, input system, authentication, networking, private game host, or media assets.

The catalog has 46 heroes / 184 slots. The default registry registers only Anti-Mage Blink and Mana Void, and Lion Hex. An explicit review assembly registers 184 candidate factories: 66 remain gated proposals and 7 are detached command drafts. Every slot now has a candidate factory; none are placeholders. Separately, a prior frozen private-host trial reports 24 integrated slots; that is not a host validation of this assembled package. The remaining 160 slots and final lifecycle / independent browser acceptance are pending. No candidate is marked release-ready. These counts describe this review snapshot, not the live game's feature count.

```js
import { createHeroRegistry } from '@dotapk/heros';
import { catalog, reviewStatus } from '@dotapk/heros/catalog';
import { installBlinkRange } from '@dotapk/heros/examples/blink-range';
const registry = createHeroRegistry(); // three default implementations
installBlinkRange(registry, { rangeScale: 0.5 });
const sealed = registry.seal(); // immutable definitions, manifests and rulesHash
```

`createRuleSession(sealed)` delivers named rule hooks using detached, frozen actor facts and only declared capability ports. The host owns transaction receipts, payment, physics, effect handles, queues, lifecycle timing and cross-reference validation. Resources must fit the actual sealed hero resource schema. Snapshot restore is scoped to public rule state; it does not restore a private world.

For local review only:

```js
import { createReviewRegistry } from '@dotapk/heros/candidates';
const candidate = createReviewRegistry({ acknowledgeDrafts: true }).seal();
```

The explicit review registry leaves proposals' capability/semantics gates closed. Importing this subpath alone has no registration side effects. Never substitute the entire review package for a privately patched host vendor package, or enable drafts using fabricated host semantics.

Run `npm test` for all shipped source-verified suites, including default, optional rule modules, schedule forwarding, assembly, and executable plugin example tests. `npm run example` demonstrates one detached Blink request. These tests are not native-host or browser evidence. Every factory uses actual shipped source digests and immutable execution parameters; registration/replacement validates prospective definitions and canonical state schemas before committing. Source or parameters change rulesHash; a matching checkpoint identity is required.

See [CONTRIBUTING.md](CONTRIBUTING.md), [SECURITY.md](SECURITY.md), [NOTICE](NOTICE) and [LICENSE](LICENSE). This candidate is prepared locally and has not been published to a public repository or package registry.
