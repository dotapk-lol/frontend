// Explicit local review assembly; importing the default entry never registers drafts.
import {heroes,createHeroRegistry} from '../index.js';
import {registerCore4} from '../rules/core4/index.js';
import {registerA} from '../rules/a/register.js';
import {registerB} from '../rules/b/register.js';
import {registerC} from '../rules/c/index.js';
import {registerLegacy0To9} from '../rules/legacy-0-9/index.js';
import {registerRemainingLegacy0To9} from '../rules/legacy-0-9/remaining.js';
import {registerLegacyNextDrafts} from '../rules/legacy-0-9/next/index.js';
import {registerLegacy10To19} from '../rules/legacy-10-19/index.js';
import {registerProposedLegacy10To19} from '../rules/legacy-10-19/proposed-behaviors.js';
import {registerRemainingLegacy10To19} from '../rules/legacy-10-19/remaining.js';
export function createReviewRegistry({acknowledgeDrafts=false,definitions=heroes}={}){
 if(acknowledgeDrafts!==true)throw Error('Review registry includes gated proposals and unverified draft handlers');
 const registry=createHeroRegistry(definitions);
 for(const register of [registerCore4,registerA,registerB,registerC,registerLegacy0To9,registerLegacyNextDrafts,registerRemainingLegacy0To9,registerLegacy10To19,registerProposedLegacy10To19,registerRemainingLegacy10To19])register(registry);
 return registry;
}
