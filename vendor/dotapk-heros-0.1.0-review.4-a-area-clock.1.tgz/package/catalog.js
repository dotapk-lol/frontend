import status from './content/slot-status.json' with {type:'json'};
import {heroes,freezeTree} from './content/index.js';
export {heroes as catalog};
export const reviewStatus=freezeTree(status);
