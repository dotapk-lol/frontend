# Trust and boundaries

Factories are reviewed static JavaScript modules. This package is not a sandbox for executing hostile plugins. Source fingerprints identify shipped files and declared immutable parameters; they do not attest arbitrary closure behavior or make untrusted JavaScript safe.

The public context exposes detached frozen facts, namespace-scoped validated state and finite declared ports. The private host remains responsible for admission, transaction receipts, unique accepted handles, round/life generations, target routing, tick order, terminal leases, resource/world bounds and atomic cross-reference checkpoint restore. Rule snapshots contain no private world. A valid public metadata shape does not prove a private handle exists.

Keep private engine and adapter code, credentials, deployment configuration, world snapshots, assets, network orchestration and account information outside the public package. Do not publish this private review candidate. Report boundary or restore failures to the project maintainers through an already authorized private channel; this package does not send reports or messages.
