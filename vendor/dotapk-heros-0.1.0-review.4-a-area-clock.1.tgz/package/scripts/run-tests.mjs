import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {spawnSync} from 'node:child_process';import {createHash} from 'node:crypto';
import {sourceManifest} from '../rules/fingerprint.js';import {suites} from './test-suites.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const actualTests=fs.readdirSync(path.join(root,'test'),{recursive:true}).filter(x=>x.endsWith('.test.mjs')).map(x=>'test/'+x).sort();
const declaredTests=suites.flatMap(s=>s.files).sort();
if(new Set(declaredTests).size!==declaredTests.length||JSON.stringify(actualTests)!==JSON.stringify(declaredTests))throw Error('Missing or unlisted shipped test suite');
for(const file of [...declaredTests,'test/host.mjs','test/b24-host.mjs','test/c/host.mjs','examples/blink-range.js','content/slot-status.json'])if(!fs.existsSync(path.join(root,file)))throw Error('Missing shipped fixture: '+file);
const sourceFiles=fs.readdirSync(root,{recursive:true}).filter(file=>!file.includes('node_modules')&&file!=='rules/fingerprint.js'&&/\.(?:js|mjs|ts|json)$/.test(file)&&fs.statSync(path.join(root,file)).isFile()).sort();
if(JSON.stringify(sourceFiles)!==JSON.stringify(Object.keys(sourceManifest).sort()))throw Error('Fingerprint source inventory mismatch');
for(const [file,digest]of Object.entries(sourceManifest))if(createHash('sha256').update(fs.readFileSync(path.join(root,file))).digest('hex')!==digest)throw Error('Source fingerprint mismatch: '+file);
let total=0;
for(const suite of suites){
 const result=spawnSync(process.execPath,['--test','--test-reporter=tap',...suite.files],{cwd:root,encoding:'utf8'});
 process.stdout.write('Suite '+suite.name+'\n'+(result.stdout??''));process.stderr.write(result.stderr??'');
 const metric=name=>Number(result.stdout?.match(new RegExp('^# '+name+' (\\d+)$','m'))?.[1]??-1);
 const report=Object.fromEntries(['tests','pass','fail','cancelled','skipped','todo'].map(k=>[k,metric(k)]));
 if(result.status!==0||report.tests<suite.minimumPass||report.pass<suite.minimumPass||report.fail!==0||report.cancelled!==0||report.skipped!==0||report.todo!==0)throw Error('Insufficient actual suite passes: '+suite.name+' '+JSON.stringify(report));total+=report.pass;
}
process.stdout.write('All '+suites.length+' shipped suites passed; actual passes '+total+'; skipped/todo/fail 0.\n');
