// Verification only. Shared prepack generates sourceManifest in a TEST COPY.
import fs from 'node:fs';import {createHash} from 'node:crypto';
import {sourceManifest} from '../../rules/fingerprint.js';import {codeIdentity} from '../../contract/code-identity.js';import {SOURCE_FILES} from '../../rules/c/common.js';
for(const name of SOURCE_FILES){const actual=createHash('sha256').update(fs.readFileSync(new URL('../../'+name,import.meta.url))).digest('hex');if(sourceManifest[name]!==actual)throw Error('Missing/stale C source fingerprint: '+name);}
console.log(JSON.stringify(codeIdentity(SOURCE_FILES)));
