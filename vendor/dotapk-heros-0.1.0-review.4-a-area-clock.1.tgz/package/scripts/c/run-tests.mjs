// Explicit C suite runner: no zero-test success, no regeneration at install time.
import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {spawnSync} from 'node:child_process';import {createHash} from 'node:crypto';import {sourceManifest} from '../../rules/fingerprint.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');
const tests=['test/c/skills.test.mjs','test/c/boundaries.test.mjs','test/c/effect-diff.test.mjs'],required=[...tests,'test/c/host.mjs','test/c/sample.mjs'];
for(const file of required)if(!fs.existsSync(path.join(root,file)))throw Error('Missing C shipped test fixture: '+file);
for(const [file,digest] of Object.entries(sourceManifest))if(/^(rules|test|scripts)\/c\//.test(file)&&(!fs.existsSync(path.join(root,file))||createHash('sha256').update(fs.readFileSync(path.join(root,file))).digest('hex')!==digest))throw Error('C source fingerprint mismatch: '+file);
const result=spawnSync(process.execPath,['--test','--test-reporter=tap',...tests],{cwd:root,encoding:'utf8'});process.stdout.write(result.stdout??'');process.stderr.write(result.stderr??'');
const count=Number(result.stdout?.match(/^# tests (\d+)$/m)?.[1]??0);if(result.status!==0||count<240)throw Error('C suite failed or insufficient executed tests: '+count);
