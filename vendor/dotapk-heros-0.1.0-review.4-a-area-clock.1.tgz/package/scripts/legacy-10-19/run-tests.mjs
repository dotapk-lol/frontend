import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';import {createHash} from 'node:crypto';
import {sourceManifest} from '../../rules/fingerprint.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');
const fixture='test/legacy-10-19/slices.test.mjs';
for(const file of [fixture,'rules/legacy-10-19/index.js','test/host.mjs'])if(!fs.existsSync(path.join(root,file)))throw Error('Missing shipped legacy fixture: '+file);
for(const [file,digest] of Object.entries(sourceManifest))if(!fs.existsSync(path.join(root,file))||createHash('sha256').update(fs.readFileSync(path.join(root,file))).digest('hex')!==digest)throw Error('Source fingerprint mismatch: '+file);
for(const [args,minimum] of [[['scripts/run-tests.mjs'],29],[['--test','--test-reporter=tap',fixture],14]]){
 const r=spawnSync(process.execPath,args,{cwd:root,encoding:'utf8'});process.stdout.write(r.stdout??'');process.stderr.write(r.stderr??'');
 const count=Number(r.stdout?.match(/^# tests (\d+)$/m)?.[1]??0);
 if(r.status!==0||count<minimum)throw Error('Legacy suite failed or insufficient executed tests: '+count);
}
