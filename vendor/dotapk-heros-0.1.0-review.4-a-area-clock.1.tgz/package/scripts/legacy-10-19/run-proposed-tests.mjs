// Dedicated draft runner. npm test remains the unchanged frozen core command.
import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {spawnSync} from 'node:child_process';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');
for(const f of ['test/legacy-10-19/proposed.test.mjs','test/legacy-10-19/proposed-host.mjs','rules/legacy-10-19/proposed-abilities.js','rules/legacy-10-19/proposed-behaviors.js','rules/legacy-10-19/proposed-validation.js'])if(!fs.existsSync(path.join(root,f)))throw Error('Missing shipped proposed fixture: '+f);
for(const [args,minimum] of [[['scripts/legacy-10-19/run-tests.mjs'],14],[['--test','--test-reporter=tap','test/legacy-10-19/proposed.test.mjs'],31]]){
 const r=spawnSync(process.execPath,args,{cwd:root,encoding:'utf8'});process.stdout.write(r.stdout??'');process.stderr.write(r.stderr??'');
 const counts=[...(r.stdout??'').matchAll(/^# tests (\d+)$/gm)].map(m=>Number(m[1]));if(r.status!==0||!counts.length||counts.at(-1)<minimum)throw Error('Proposed suite failed or insufficient executed tests');
}
