import {BATTLE_ABI,codeIdentity,EMPTY_STATE_SCHEMA} from '../../index.js';
import {PROPOSED_SEMANTICS,PROPOSED_SLOTS,PROPERTY_KEYS} from './proposed-abilities.js';
import {finite,bool,actorId,gate,properties,view} from './proposed-validation.js';
const SOURCES=['rules/legacy-10-19/proposed-abilities.js','rules/legacy-10-19/proposed-behaviors.js','rules/legacy-10-19/proposed-validation.js'];
const stageKinds=new Set(['attack-properties','damage-properties','movement-properties','interval-properties']);
export function proposedLegacyFactory(heroId,slot,{hostSemantics=null}={}){
 if(!PROPOSED_SLOTS.some(([h,s])=>h===heroId&&s===slot))throw Error('Unsupported proposed legacy slot');
 return {abiVersion:BATTLE_ABI,parameters:{heroId,slot,hostSemantics},create({hero,definition,parameters}){
  if(Object.keys(parameters).sort().join(',')!=='heroId,hostSemantics,slot')throw Error('Unknown proposed configuration');
  const {heroId,slot}=parameters,id=definition.id,m=definition.mvp;
  if(hero.registryNumericId!==heroId||hero.abilities[slot].id!==id||!PROPOSED_SLOTS.some(([h,s])=>h===heroId&&s===slot))throw Error('Wrong proposed identity');
  if(parameters.hostSemantics!==null&&parameters.hostSemantics!==PROPOSED_SEMANTICS)throw Error('Unknown proposed host semantics');
  const metadata={behaviorId:'legacy-10-19/proposed/'+id,revision:'1.0.0',namespace:'heros/legacy-10-19/'+id,...codeIdentity(SOURCES),stateSchema:EMPTY_STATE_SCHEMA};
  finite(m.duration_s,'duration_s',0,3600);finite(m.radius_wu,'radius_wu');
  const planCast=(ctx,facts)=>{
   const plan={manaCost:m.mana,cooldownSeconds:m.cooldown_s,chargeCost:m.charges?1:0,windupSeconds:m.startup_frames/60,recoverySeconds:m.recovery_frames/60,action:'cast'};
   if(parameters.hostSemantics!==PROPOSED_SEMANTICS||facts.legacySemantics!==PROPOSED_SEMANTICS)return {...plan,accepted:false,reason:'gated-host-semantics'};
   gate(parameters,facts);bool(facts.actionReady,'actionReady');finite(facts.manaAvailable,'manaAvailable');finite(facts.cooldownRemaining,'cooldownRemaining');finite(facts.chargesAvailable,'chargesAvailable');
   return {...plan,accepted:facts.actionReady&&facts.manaAvailable>=m.mana&&facts.cooldownRemaining===0&&(!m.charges||facts.chargesAvailable>0)};
  };
  if(id==='earthshaker_echo'){
   finite(m.damage,'damage');finite(m.stun_s,'stun_s',0,60);finite(m.hitstun_s,'hitstun_s',0,60);
   if(!['physical','magical','pure'].includes(m.damage_type))throw Error('Invalid proposed damage type');bool(m.blockable,'blockable');
   return {...metadata,planCast,requires:['damage'],activate(ctx,cast){
    gate(parameters,cast);if(cast.aftershockCompleted!==true)throw Error('GATED: missing owned Aftershock stage completion');
    const f=ctx.actor(cast.owner),t=ctx.actor(cast.target);
    if(Math.abs(t.x-f.x)<=m.radius_wu+22&&(m.height!=='ground'||t.y<45))ctx.damage({source:cast.owner,target:cast.target,abilityId:id,amount:m.damage,type:m.damage_type,blockable:m.blockable,stunSeconds:m.stun_s,hitstunSeconds:m.hitstun_s});
    return {presentation:{kind:'legacy-ring',actor:cast.owner,y:60,radius:m.radius_wu,lifeSeconds:.65}};
   }};
  }
  const coefficients=properties(id,m);
  const requires=id==='tidehunter_anchor'?['damage','status']:['status'];
  const nativeKey=id==='tidehunter_anchor'?'weak':id;
  const status=(owner,target)=>({owner,target,abilityId:id,key:nativeKey,duration:id==='tidehunter_anchor'?(m.debuff_duration_s||m.duration_s||2):(m.duration_s||2),polarity:id==='tidehunter_anchor'?'negative':'positive',dispel:id==='tidehunter_anchor'?'basic':'none',pierces:id==='tidehunter_anchor',values:{profile:PROPOSED_SEMANTICS,coefficients,lifecycle:id==='earthshaker_totem'?'consume-every-basic-hit':id==='mirana_moonlight'?'moonlight-reveal':'native-legacy',...(id==='mirana_moonlight'?{initialRevealSeconds:0}:{})}});
  const project=(ctx,event)=>{
   gate(parameters,event);if(event.kind!=='legacy-properties'||!stageKinds.has(event.stage))throw Error('Missing proposed property collection stage');
   const rows=view(ctx,event,definition,nativeKey);
   return {nativeProperties:rows.length?rows[0].coefficients:{}};
  };
  const impl={...metadata,planCast,requires,projectAttack:project,projectDamage:project,projectInterval:project,onStage(ctx,event){
   gate(parameters,event);if(event.kind!=='legacy-properties'||event.stage!=='movement-properties')throw Error('Missing proposed movement property stage');return project(ctx,event);
  },activate(ctx,cast){
   gate(parameters,cast);
   if(id==='earthshaker_totem'&&cast.aftershockCompleted!==true)throw Error('GATED: missing owned Aftershock stage completion');
   if(id==='tidehunter_anchor'){
    const f=ctx.actor(cast.owner),t=ctx.actor(cast.target);
    if(Math.abs(t.x-f.x)<=m.radius_wu+22&&(m.height!=='ground'||t.y<45)){
     // Proposed bounded descriptor is committed by the UNIQUE native damage
     // transaction at its original unguarded after-hit-status stage. A second
     // status.apply after the receipt would be ordered incorrectly.
     ctx.damage({source:cast.owner,target:cast.target,abilityId:id,amount:m.damage,type:m.damage_type,blockable:m.blockable,stunSeconds:m.stun_s,hitstunSeconds:m.hitstun_s,onLandedLegacyStatus:status(cast.owner,cast.target)});
    }
    return {presentation:{kind:'legacy-ring',actor:cast.owner,y:60,radius:m.radius_wu,lifeSeconds:.65}};
   }
   ctx.status.apply(status(cast.owner,cast.owner));
   return {presentation:{kind:'legacy-buff-ring',actor:cast.owner,yOffset:70,radius:100,lifeSeconds:.7}};
  }};
  if(id==='tidehunter_anchor'){finite(m.damage,'damage');finite(m.stun_s,'stun_s',0,60);finite(m.hitstun_s,'hitstun_s',0,60);finite(m.debuff_duration_s,'debuff_duration_s',0,3600);if(!['physical','magical','pure'].includes(m.damage_type))throw Error('Invalid proposed damage type');bool(m.blockable,'blockable');}
  if(id==='earthshaker_totem')impl.onAttack=(ctx,event)=>{
   gate(parameters,event);if(event.kind!=='legacy-basic-hit-completed')throw Error('Missing every-basic-hit completion event');bool(event.landed,'landed');actorId(event.actor);if(event.actor!==event.owner)throw Error('Wrong Totem affected actor');
   const rows=view(ctx,event,definition),consumed=[];for(const r of rows){ctx.status.remove(r.handle);consumed.push(r.handle);}return {consumed};
  };
  if(id==='mirana_moonlight'){
   const reveal=(ctx,event)=>{gate(parameters,event);actorId(event.actor);if(event.actor!==event.owner)throw Error('Wrong Moonlight affected actor');const rows=view(ctx,event,definition);return {legacyRevealUpdates:rows.map(r=>({handle:r.handle,revealSeconds:1.5}))};};
   impl.onCastCommitted=(ctx,event)=>{if(typeof event.castAbilityId!=='string'||!event.castAbilityId||typeof event.castId!=='string'||!event.castId)throw Error('Missing separate committed cast identity');return reveal(ctx,event);};
   impl.onAttack=(ctx,event)=>{if(event.kind!=='legacy-attack-started'||typeof event.attackActionId!=='string'||!event.attackActionId||event.attackActionId.length>128)throw Error('Missing attack-start identity');return reveal(ctx,event);};
  }
  return impl;
 }};
}
// Deliberately separate from registerLegacy10To19 and default registrations.
export function registerProposedLegacy10To19(registry,parameters={}){
 for(const [heroId,slot] of PROPOSED_SLOTS)registry.registerFactory(heroId,slot,proposedLegacyFactory(heroId,slot,parameters));return registry;
}
export {PROPOSED_SEMANTICS,PROPOSED_SLOTS};
