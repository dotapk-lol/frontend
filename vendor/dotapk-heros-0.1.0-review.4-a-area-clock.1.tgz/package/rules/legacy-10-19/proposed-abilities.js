// NOT a frozen core capability. The integrator must approve this finite semantic
// profile and emit its read-only event handshake before any draft executes.
export const PROPOSED_SEMANTICS='legacy-status-v1/proposal.1';
export const PROPOSED_SLOTS=Object.freeze([[10,1],[10,3],[11,3],[12,2],[12,3],[14,2],[14,3],[19,2]].map(Object.freeze));
export const PROPERTY_KEYS=Object.freeze(Object.fromEntries(Object.entries({
 earthshaker_totem:['next_attack_override','next_attack_range_bonus'],
 mirana_moonlight:['move_multiplier','outgoingMultiplier'],
 sven_warcry:['move_multiplier','physical_reduction'],
 sven_strength:['attack_bonus','cleave_bonus','slow_resistance'],
 windranger_windrun:['move_multiplier','basic_attack_evasion'],
 windranger_focus:['attack_interval_override_s','attack_damage_override','move_attack'],
 tidehunter_anchor:['attack_damage_debuff']
}).map(([id,keys])=>[id,Object.freeze(keys)])));
