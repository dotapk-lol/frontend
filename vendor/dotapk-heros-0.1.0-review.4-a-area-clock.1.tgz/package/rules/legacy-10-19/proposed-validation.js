import {PROPOSED_SEMANTICS,PROPERTY_KEYS} from './proposed-abilities.js';
export function finite(value,name,min=0,max=1e7){if(typeof value!=='number'||!Number.isFinite(value)||value<min||value>max)throw Error('Invalid proposed legacy fact: '+name);return value;}
export function actorId(value){if(value!==0&&value!==1)throw Error('Invalid proposed actor');return value;}
export function bool(value,name){if(typeof value!=='boolean')throw Error('Missing proposed boolean fact: '+name);return value;}
export function gate(parameters,event){
 if(parameters.hostSemantics!==PROPOSED_SEMANTICS||event.legacySemantics!==PROPOSED_SEMANTICS)throw Error('GATED: missing integrator-approved '+PROPOSED_SEMANTICS);
 actorId(event.owner);actorId(event.target);
}
export function properties(id,m){
 const keys=PROPERTY_KEYS[id];if(!keys)throw Error('No proposed property family');
 const out={};for(const k of keys){const v=m[k];if(k==='move_attack')out[k]=bool(v,k);else out[k]=finite(v,k,k==='attack_interval_override_s'?Number.MIN_VALUE:0,['physical_reduction','slow_resistance','basic_attack_evasion','attack_damage_debuff'].includes(k)?1:k==='attack_interval_override_s'?3600:1e7);}return out;
}
export function view(ctx,event,definition,key=definition.id){
 actorId(event.actor);
 const rows=ctx.status.query(event.actor,key);
 if(!Array.isArray(rows)||rows.length>1)throw Error('Invalid native legacy unique status view');
 return rows.map(r=>{
  if(r.key!==key||typeof r.handle!=='string'||!r.handle||r.handle.length>128)throw Error('Missing native status handle');
  finite(r.remainingSeconds,'remainingSeconds',0,3600);bool(r.effective,'effective');actorId(r.owner);actorId(r.target);
  if(r.target!==event.actor)throw Error('Mismatched native status target');
  // Native key replacement may leave another source's record. Its owner must
  // project it; this callback cannot consume or update that other source.
  if(r.owner!==event.owner||r.abilityId!==definition.id)return null;
  if(r.values?.profile!==PROPOSED_SEMANTICS||!r.values.coefficients||Object.keys(r.values.coefficients).sort().join(',')!==PROPERTY_KEYS[definition.id].slice().sort().join(','))throw Error('Invalid proposed status profile');
  const coefficients=properties(definition.id,r.values.coefficients);
  if(definition.id==='mirana_moonlight')finite(r.revealSeconds,'revealSeconds',0,1.5);
  return {...r,coefficients};
 }).filter(r=>r&&r.remainingSeconds>1e-8&&r.effective);
}
