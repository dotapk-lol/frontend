import {createBStateSchema} from './state.js';
// Detached per-registry coefficients, never the default content or a private host.
const caches=new WeakMap();
export function model(config){let m=caches.get(config.definitions);if(!m){m={heroes:new Map(),abilities:new Map(),stateSchema:createBStateSchema(),coefficientSchemas:new Map(),maxHp:Math.max(...config.definitions.map(h=>h.combatHp||h.hp*2.8))};for(const h of config.definitions){m.heroes.set(h.registryNumericId,h);for(const a of h.abilities)m.abilities.set(a.id,a);}for(const id of [57,58,62,71,81,82]){const h=m.heroes.get(id);if(!h||!Number.isFinite(h.attributes18?.str)||h.attributes18.str<0||!Number.isFinite(h.attributes18?.agi)||h.attributes18.agi<0||h.move_speed<=0)throw Error('Invalid B derived hero coefficients');}caches.set(config.definitions,m);}return m;}
export const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
export const number=(n,label)=>{if(!Number.isFinite(n))throw Error('Missing finite B fact: '+label);return n;};
export function coefficient(m,id,key){return number(m.abilities.get(id)?.official?.params?.[key],id+'.'+key);}
export function near(ctx,owner,target,r){const f=ctx.actor(owner),t=ctx.actor(target);return t.alive&&Math.abs(t.x-f.x)<=r+22&&Math.abs(f.y-t.y)<105;}
export function positive(ctx,actor,key){return ctx.status.query(actor,key).find(s=>s.polarity==='positive');}
export function active(status,actor){return status.enabled===true||(status.enabled===undefined&&(status.polarity==='positive'||!actor.invulnerable&&(status.pierces||!actor.debuffImmune)));}
export function statuses(event,actor){if(!Array.isArray(event.statuses))throw Error('Missing B readonly status facts');return event.statuses.filter(s=>active(s,actor));}
export function baseSpeed(m,actor){const h=m.heroes.get(actor.heroId);return 100+(h.attributes18?.agi??h.level18?.agility??0);}
export function plan(ctx,facts,definition){const m=definition.mvp,f=ctx.actor(facts.owner),t=ctx.actor(facts.target);let ok=facts.actionReady===true&&!m.passive&&f.alive&&!f.silenced&&facts.cooldownRemaining<=1e-8&&facts.manaAvailable>=m.mana;
 if(definition.id==='huskar_life_break'&&f.rooted)ok=false;
 if(['huskar_life_break','night_stalker_void','ogre_magi_fireblast','ogre_magi_ignite'].includes(definition.id)&&(!t.alive||t.invulnerable||Math.abs(t.x-f.x)>m.range_wu+22))ok=false;
 if(definition.id==='jakiro_dual_breath'&&(t.invulnerable||!near(ctx,facts.owner,facts.target,m.range_wu)))ok=false;
 if(['jakiro_ice_path','jakiro_macropyre','alchemist_acid_spray','treant_natures_grasp'].includes(definition.id)&&(!Number.isFinite(facts.aimX)||facts.aimX<45||facts.aimX>1155||Math.abs(facts.aimX-f.x)>m.range_wu+22))ok=false;
 return {accepted:ok,...(!ok?{reason:m.passive?'passive':'not-admitted'}:{}),manaCost:m.mana,cooldownSeconds:m.cooldown_s,chargeCost:0,windupSeconds:m.startup_frames/60,recoverySeconds:m.recovery_frames/60,action:'cast'};}
export const reflection=route=>route.reflected?{reflected:true,origin:route.originalOwner}:{};
export function damage(ctx,id,source,target,amount,type='magical',reflected=false){return ctx.damage({source,target,abilityId:id,amount,type,dot:true,blockable:false,reflected,noReflect:reflected,noLifesteal:reflected});}
export function status(ctx,id,owner,target,duration,values={},options={}){return ctx.status.apply({owner,target,abilityId:id,key:options.key??id,duration,polarity:options.positive?'positive':'negative',dispel:options.dispel??'basic',pierces:options.pierces??false,values:{abilityId:id,...(!options.positive?{hostile:true,polarity:'hostile'}:{}),...values},...(options.interval?{intervalSeconds:options.interval}:{} )});}
export function buff(ctx,id,owner,duration,values={}){return status(ctx,id,owner,owner,duration,values,{positive:true,dispel:id==='huskar_life_break'?'none':'basic'});}
export function control(ctx,id,owner,target,type,duration,pierces=false){return ctx.control.apply({owner,target,abilityId:id,key:id,type,duration,pierces,dispel:'strong'});}
export function route(ctx,id,cast,range){return ctx.target.route({owner:cast.owner,target:cast.target,abilityId:id,range,reflectable:true,reflected:cast.reflected===true});}
export function immediateMove(ctx,id,actor,castId,destinationX){return ctx.motion({actor,abilityId:id,castId,kind:'dash',destinationX,speed:0,duration:0});}
export function combineInterval(baseSeconds,baseAttackSpeed,contributions){let attackSpeed=0,baseAttackTime=null;for(const c of contributions){attackSpeed+=number(c.attackSpeed??0,'attack speed');if(c.baseAttackTime!==undefined)baseAttackTime=number(c.baseAttackTime,'base attack time');}const raw=baseAttackTime===null?baseSeconds:baseAttackTime*100/baseAttackSpeed;return raw*baseAttackSpeed/clamp(baseAttackSpeed+attackSpeed,20,700);}
export function combineAttack(baseAttack,contributions){let bonus=0,reduction=0;for(const c of contributions){bonus+=number(c.attackBonus??0,'attack bonus');reduction+=number(c.baseAttackReduction??0,'base attack reduction');}return Math.max(0,baseAttack+bonus-baseAttack*clamp(reduction,0,1));}
export function combineMovement(contributions){let bonus=0,slow=0;for(const c of contributions){bonus+=number(c.moveBonus??0,'move bonus');slow+=number(c.slow??0,'slow');}return(1+bonus)*(1-clamp(slow,0,1));}
