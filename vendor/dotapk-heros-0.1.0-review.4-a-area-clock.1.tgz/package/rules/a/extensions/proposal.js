import {canonicalExtension,EXTENSION_SOURCE_FILES} from './canonical.js';
import {BATTLE_ABI,codeIdentity} from '../../../index.js';
/** Review-only registry binding. It returns intents and never dispatches missing ports. */
export const extensionProposalFactory=Object.freeze({abiVersion:BATTLE_ABI,parameters:{mode:'proposal-only'},create(config){
 if(config.parameters?.mode!=='proposal-only'||Object.keys(config.parameters).length!==1)throw Error('A_INVALID_PROPOSAL_PARAMETERS');
 const {rule,stateSchema}=canonicalExtension(config);
 return {behaviorId:'heros/a/proposal/'+config.definition.id,revision:'2.0.0',...codeIdentity([...EXTENSION_SOURCE_FILES,'rules/a/extensions/proposal.js']),requires:[],namespace:'heros/a/proposal/'+config.definition.id,stateSchema,
  onStage(ctx,event){if(event.kind!=='extension-proposal')throw Error('A_PROPOSAL_EVENT_REQUIRED');const handler=rule.handlers[event.handler];if(!handler)throw Error('A_UNKNOWN_PROPOSAL_HANDLER');
   const facts={...event.facts};if(facts.owner!==undefined)facts.owner=ctx.actor(facts.owner);if(facts.target!==undefined)facts.target=ctx.actor(facts.target);
   const next=handler(ctx.state.read(),facts);ctx.state.write(next.state);return {requiresHostContract:true,commands:next.commands};
  }
 };
}});
