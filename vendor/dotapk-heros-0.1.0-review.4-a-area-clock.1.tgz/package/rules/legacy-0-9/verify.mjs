// Run from a source directory or an actually extracted package. The frozen
// contract runner validates all fingerprints and executes at least 29 tests.
import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {spawnSync} from 'node:child_process';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');
for(const file of ['test/legacy-0-9.test.mjs','test/legacy-projections.test.mjs'])if(!fs.existsSync(path.join(root,file)))throw Error('Missing owned shipped test: '+file);
for(const files of [['scripts/run-tests.mjs'],['--test','--test-reporter=tap','test/legacy-0-9.test.mjs','test/legacy-projections.test.mjs']]) {
  const result=spawnSync(process.execPath,files,{cwd:root,encoding:'utf8'});
  process.stdout.write(result.stdout??'');process.stderr.write(result.stderr??'');
  if(result.status!==0)throw Error('Rule verification failed');
  const minimum=files[0]==='scripts/run-tests.mjs'?29:15;
  if(Number(result.stdout.match(/^# tests (\d+)$/m)?.[1]??0)<minimum)throw Error('Insufficient executed rule tests');
}
