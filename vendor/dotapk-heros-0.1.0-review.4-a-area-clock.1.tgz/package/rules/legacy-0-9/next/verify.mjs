import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {spawnSync} from 'node:child_process';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..');
for(const file of ['test/legacy-next.test.mjs','test/legacy-next-recorder.mjs'])if(!fs.existsSync(path.join(root,file)))throw Error('Missing shipped draft test: '+file);
for(const [args,minimum]of [[['rules/legacy-0-9/verify.mjs'],44],[['--test','--test-reporter=tap','test/legacy-next.test.mjs'],22]]) {
  const result=spawnSync(process.execPath,args,{cwd:root,encoding:'utf8'});process.stdout.write(result.stdout??'');process.stderr.write(result.stderr??'');
  if(result.status!==0)throw Error('Public draft verification failed');
  const count=[...result.stdout.matchAll(/^# tests (\d+)$/gm)].reduce((sum,m)=>sum+Number(m[1]),0);
  if(count<minimum)throw Error('Insufficient executed public tests: '+count);
}
