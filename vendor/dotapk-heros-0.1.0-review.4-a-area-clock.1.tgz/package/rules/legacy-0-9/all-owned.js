import {registerLegacy0To9} from './index.js';
import {registerLegacyNextDrafts} from './next/index.js';
import {registerRemainingLegacy0To9} from './remaining.js';
// Integrator opt-in only; public defaults and the two preserved entries stay intact.
export function registerAllLegacy0To9(registry,remainingParameters={}){return registerRemainingLegacy0To9(registerLegacyNextDrafts(registerLegacy0To9(registry)),remainingParameters);}
