// Owned review runner. Neither adds scripts to the shared package nor changes
// the contract3 runner. Counts actual passes, not discovered or skipped tests.
import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {spawnSync} from 'node:child_process';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');
const fixtures=['test/legacy-0-9.test.mjs','test/legacy-projections.test.mjs','test/legacy-next.test.mjs','test/legacy-next-recorder.mjs','test/legacy-remaining.test.mjs','test/legacy-remaining-recorder.mjs'];
for(const file of fixtures)if(!fs.existsSync(path.join(root,file)))throw Error('Missing owned shipped fixture: '+file);
for(const [args,min]of [[['scripts/run-tests.mjs'],30],[['--test','--test-reporter=tap',...fixtures.filter(f=>f.endsWith('.test.mjs'))],106]]){
 const r=spawnSync(process.execPath,args,{cwd:root,encoding:'utf8'});process.stdout.write(r.stdout??'');process.stderr.write(r.stderr??'');const metric=n=>Number(r.stdout?.match(new RegExp('^# '+n+' (\\d+)$','m'))?.[1]??-1);
 if(r.status!==0||metric('pass')<min||metric('fail')!==0||metric('skipped')!==0||metric('todo')!==0||metric('cancelled')!==0)throw Error('Insufficient real owned passes or failed/skipped/todo/cancelled verification');
}
